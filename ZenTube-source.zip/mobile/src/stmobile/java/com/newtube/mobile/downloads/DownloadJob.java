package com.newtube.mobile.downloads;

import android.content.Context;
import android.media.MediaMuxer;
import android.util.Log;

import androidx.annotation.Nullable;

import com.liskovsoft.mediaserviceinterfaces.data.MediaFormat;
import com.liskovsoft.mediaserviceinterfaces.data.MediaItemFormatInfo;
import com.liskovsoft.smartyoutubetv2.common.misc.NetPath;
import com.liskovsoft.youtubeapi.service.YouTubeMediaItemService;
import com.liskovsoft.youtubeapi.service.YouTubeServiceManager;
import com.liskovsoft.youtubeapi.videoinfo.V2.VideoInfoService;
import com.liskovsoft.smartyoutubetv2.tv.R;
import com.newtube.mobile.player.Media3SourceFactory;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Runs one {@link DownloadItem} to completion on the service's worker thread: fetch the parts,
 * fetch the thumbnail, mux, publish. Progress lands on the item and goes out through the
 * registry; the service turns it into the notification.
 */
final class DownloadJob {
    private static final String TAG = DownloadJob.class.getSimpleName();

    interface Listener {
        void onProgress(DownloadItem item);
    }

    private final Context mContext;
    private final DownloadItem mItem;
    private final DownloadRegistry mRegistry;
    private final DownloadStorage mStorage;
    private final StreamFetcher mFetcher;
    private final Listener mListener;
    private long mLastNotifyMs;
    /** Where a part download's files start in their streams (issue #241), for the mux. */
    private long mVideoPartStartMs;
    private long mAudioPartStartMs;

    DownloadJob(Context context, DownloadItem item, DownloadRegistry registry, Listener listener) {
        mContext = context.getApplicationContext();
        mItem = item;
        mRegistry = registry;
        mStorage = new DownloadStorage(mContext);
        mFetcher = new StreamFetcher(Media3SourceFactory.MEDIA_USER_AGENT);
        mListener = listener;
    }

    void run() {
        mItem.state = DownloadItem.STATE_DOWNLOADING;
        mItem.error = null;
        mRegistry.notifyChanged();

        File videoPart = mItem.isAudioOnly() ? null : new File(DownloadRegistry.partsDir(mContext), mItem.id + ".video");
        File audioPart = mItem.audioItag != null ? new File(DownloadRegistry.partsDir(mContext), mItem.id + ".audio") : null;

        try {
            fetchThumbnail();
            fetchParts(videoPart, audioPart);
            if (mItem.cancelRequested) {
                throw new StreamFetcher.CancelledException();
            }
            publish(videoPart, audioPart);
            mItem.state = DownloadItem.STATE_DONE;
            mItem.error = null;
            retirePreviousCopies();
            deleteParts(videoPart, audioPart);
        } catch (StreamFetcher.CancelledException e) {
            if (mItem.cancelRequested) {
                deleteParts(videoPart, audioPart);
                mRegistry.remove(mItem);
                return;
            }
            // Paused: the parts stay, and Resume appends to them.
            mItem.state = DownloadItem.STATE_PAUSED;
        } catch (StreamFetcher.UrlRefusedException e) {
            Log.w(TAG, "download refused: " + e);
            fail(mContext.getString(R.string.mobile_download_error_link));
        } catch (IOException e) {
            Log.w(TAG, "download failed: " + e);
            fail(reason(e));
        } catch (RuntimeException e) {
            Log.e(TAG, "download crashed", e);
            fail(reason(e));
        }

        mRegistry.notifyChanged();
    }

    /**
     * Issue #317: what went wrong, not only that it did - full storage says so, and anything else
     * carries its cause in brackets, so a screenshot is enough to tell why.
     */
    private String reason(Throwable e) {
        Throwable root = e;
        for (Throwable t = e; t != null; t = t.getCause()) {
            String m = String.valueOf(t.getMessage());
            if (m.contains("ENOSPC") || m.contains("No space left")) {
                return mContext.getString(R.string.mobile_download_error_space);
            }
            root = t;
        }
        String detail = root.getMessage() != null ? root.getMessage() : root.getClass().getSimpleName();
        if (detail.length() > 80) detail = detail.substring(0, 80) + "…";
        return mContext.getString(mItem.state == DownloadItem.STATE_PROCESSING
                ? R.string.mobile_download_error_save : R.string.mobile_download_error_detail, detail);
    }

    private void fail(String message) {
        mItem.state = DownloadItem.STATE_FAILED;
        mItem.error = message;
    }

    // ---------------------------------------------------------------------------------
    // Fetch
    // ---------------------------------------------------------------------------------

    private void fetchThumbnail() {
        if (mItem.thumbPath != null && new File(mItem.thumbPath).exists()) {
            return;
        }
        if (mItem.thumbUrl == null) {
            return;
        }
        File thumb = new File(DownloadRegistry.dir(mContext), mItem.id + ".jpg");
        if (mFetcher.fetchSmall(mItem.thumbUrl, thumb) != null) {
            mItem.thumbPath = thumb.getAbsolutePath();
        }
    }

    /** Client routes to walk when googlevideo refuses the links, like the player's remint loop. */
    private static final int MAX_ROUTE_ATTEMPTS = 4;

    private void fetchParts(@Nullable File videoPart, @Nullable File audioPart) throws IOException {
        // The URLs from the enqueue moment serve a fresh job; a Retry (or a link the server
        // meanwhile refused) resolves the same itags again from a fresh format info.
        if (mItem.videoUrl == null && mItem.audioUrl == null) {
            resolveUrls(videoPart, audioPart);
        } else if (mItem.audioUrl != null) {
            NetPath.log("download audio enqueue video=" + mItem.videoId + " itag=" + mItem.audioItag
                    + " track=" + mItem.audioTrack);
        }

        for (int attempt = 1; ; attempt++) {
            try {
                fetchPartsOnce(videoPart, audioPart);
                return;
            } catch (StreamFetcher.UrlRefusedException refused) {
                if (attempt >= MAX_ROUTE_ATTEMPTS) {
                    throw refused;
                }
                // A media 403 is the ordinary fate of one /player client's links (the TV routes
                // without a PO token, measured on the Pixel: the player itself gets it and
                // recovers). Do exactly what ErrorFixerController does: quarantine the route,
                // rotate the client, mint fresh links for the same itags.
                Log.w(TAG, "links refused (route " + attempt + "/" + MAX_ROUTE_ATTEMPTS + "), rotating client: " + refused);
                NetPath.log("download route-refused attempt=" + attempt + " video=" + mItem.videoId);
                // Blame the client that served THIS item's links, not whatever the player or a
                // preload resolved last (netbench audit C-12).
                VideoInfoService.instance().anchorRouteToVideo(mItem.videoId);
                VideoInfoService.instance().markCurrentPlaybackRouteForbidden();
                YouTubeServiceManager.instance().applyNoPlaybackFix();
                resolveUrls(videoPart, audioPart);
            }
        }
    }

    private void fetchPartsOnce(@Nullable File videoPart, @Nullable File audioPart) throws IOException {
        // Issue #241: a part of the video fetches only the fragments that cover it.
        ClipRanges.Plan videoPlan = videoPart != null ? clipPlan(mItem.videoUrl, mItem.videoInit, mItem.videoIndex) : null;
        ClipRanges.Plan audioPlan = audioPart != null ? clipPlan(mItem.audioUrl, mItem.audioInit, mItem.audioIndex) : null;
        mVideoPartStartMs = videoPlan != null ? videoPlan.startMs : 0;
        mAudioPartStartMs = audioPlan != null ? audioPlan.startMs : 0;
        long videoLen = videoPlan != null ? videoPlan.fileLength() : mItem.videoLength;
        long audioLen = audioPlan != null ? audioPlan.fileLength() : mItem.audioLength;
        long total = videoLen > 0 && (audioPart == null || audioLen > 0) ? videoLen + Math.max(0, audioLen) : -1;
        if (total > 0) {
            mItem.bytesTotal = total;
        }

        final long[] done = {0, 0};
        if (videoPart != null) {
            if (mItem.videoUrl == null) {
                throw new IOException("no video link");
            }
            mFetcher.fetch(mItem.videoUrl, videoPart, videoLen, startPart(videoPart, videoPlan), (fileBytes, streamTotal) -> {
                done[0] = fileBytes;
                return report(done[0] + done[1]);
            });
            done[0] = videoPart.length();
        }
        if (audioPart != null) {
            if (mItem.audioUrl == null) {
                throw new IOException("no audio link");
            }
            // Synced before any byte: what the part holds must survive a process death.
            DownloadOptions.writeAudioPartTrack(audioPart, mItem.audioTrack);
            mFetcher.fetch(mItem.audioUrl, audioPart, audioLen, startPart(audioPart, audioPlan), (fileBytes, streamTotal) -> {
                done[1] = fileBytes;
                return report(done[0] + done[1]);
            });
            done[1] = audioPart.length();
        }
        report(done[0] + done[1]);
    }

    /**
     * The fragments of a part download, or null to fetch the stream whole: not a part, a WebM or
     * progressive stream (no sidx), or an index that does not read.
     */
    @Nullable
    private ClipRanges.Plan clipPlan(@Nullable String url, @Nullable String init, @Nullable String index)
            throws IOException {
        long[] initRange = ClipRanges.range(init);
        long[] indexRange = ClipRanges.range(index);
        if (!mItem.isClip() || url == null || initRange == null || indexRange == null
                || initRange[0] != 0 || indexRange[1] > 1024 * 1024) {
            return null;
        }
        byte[] head = mFetcher.fetchBytes(url, 0, indexRange[1]);
        ClipRanges.Plan plan = ClipRanges.plan(head, (int) initRange[1], (int) indexRange[0],
                mItem.clipStartMs, mItem.clipEndMs);
        NetPath.log("download part-plan video=" + mItem.videoId + " ok=" + (plan != null)
                + (plan != null ? " bytes=" + plan.fileLength() : ""));
        return plan;
    }

    /** Writes a part plan's header unless the file already holds it; the shift for the rest. */
    private static long startPart(File part, @Nullable ClipRanges.Plan plan) throws IOException {
        if (plan == null) {
            return 0;
        }
        if (!part.exists() || part.length() < plan.header.length || part.length() > plan.fileLength()) {
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(part, false)) {
                out.write(plan.header);
            }
        }
        return plan.from - plan.header.length;
    }

    private boolean report(long bytesDone) {
        mItem.bytesDone = bytesDone;
        long now = System.currentTimeMillis();
        mItem.sampleSpeed(now);
        if (now - mLastNotifyMs >= 500) {
            mLastNotifyMs = now;
            mRegistry.notifyChanged();
            mListener.onProgress(mItem);
        }
        return !mItem.cancelRequested && !mItem.pauseRequested;
    }

    /**
     * Fresh links for the itags this item was created with. A part file kept from an earlier
     * attempt is only resumed when it provably holds a prefix of the stream just resolved:
     * {@link StreamFetcher#fetch} appends from the file's length, so bytes of another language
     * variant (an item saved before the track was recorded, or a variant that vanished and fell
     * back to the original) would be spliced with the new stream, or skip the fetch outright
     * when the stale part is already longer.
     */
    private void resolveUrls(@Nullable File videoPart, @Nullable File audioPart) throws IOException {
        MediaItemFormatInfo info;
        try {
            info = YouTubeMediaItemService.instance()
                    .getFormatInfoObserve(mItem.videoId).blockingFirst();
        } catch (RuntimeException e) {
            throw new IOException("format info unavailable: " + e.getMessage(), e);
        }
        if (info == null || info.isUnplayable()) {
            throw new IOException("video unavailable");
        }

        MediaFormat video = mItem.videoItag != null ? findByItag(info.getAdaptiveFormats(), mItem.videoItag) : null;
        if (video == null && mItem.videoItag != null) {
            video = findByItag(info.getUrlFormats(), mItem.videoItag);
        }
        // Not findByItag: every language variant of a dubbed video shares the audio itag, and
        // the first one listed is often an auto-dub (issue #29). Same language as the picker chose.
        MediaFormat audio = mItem.audioItag != null
                ? DownloadOptions.pickAudio(info.getAdaptiveFormats(), mItem.audioItag, mItem.audioTrack) : null;

        if (mItem.videoItag != null && video == null) {
            throw new StreamFetcher.UrlRefusedException(0);
        }
        if (mItem.audioItag != null && audio == null) {
            throw new StreamFetcher.UrlRefusedException(0);
        }

        mItem.videoUrl = video != null ? video.getUrl() : null;
        mItem.audioUrl = audio != null ? audio.getUrl() : null;
        long videoLength = DownloadOptions.lengthOf(video);
        long audioLength = DownloadOptions.lengthOf(audio);
        String resolvedTrack = DownloadOptions.audioTrackKey(audio);

        if (videoPart != null && DownloadOptions.mustRestartPart(lengthOfPart(videoPart), videoLength)) {
            NetPath.log("download part-reset video=" + mItem.videoId + " part=video bytes=" + videoPart.length());
            deletePart(videoPart);
        }
        // The part's identity is its sidecar (written by fetchPartsOnce), not mItem.audioTrack:
        // the registry write is async and may not land before a process death.
        if (audioPart != null && audio != null
                && DownloadOptions.mustRestartAudioPart(audioPart, resolvedTrack, audioLength)) {
            NetPath.log("download part-reset video=" + mItem.videoId + " part=audio bytes=" + audioPart.length()
                    + " stored=" + DownloadOptions.readAudioPartTrack(audioPart) + " resolved=" + resolvedTrack);
            deletePart(audioPart);
        }
        if (resolvedTrack != null && !resolvedTrack.equals(mItem.audioTrack)) {
            mItem.audioTrack = resolvedTrack;
            mRegistry.notifyChanged();
        }
        if (audio != null) {
            MediaFormat firstByItag = findByItag(info.getAdaptiveFormats(), mItem.audioItag);
            NetPath.log("download audio resolve video=" + mItem.videoId + " itag=" + audio.getITag()
                    + " lang=" + audio.getLanguage() + " track=" + audio.getAudioTrackId()
                    + " wanted=" + mItem.audioTrack
                    + " firstByItag=" + (firstByItag != null ? firstByItag.getLanguage() : null));
        }
        mItem.videoLength = videoLength;
        mItem.audioLength = audioLength;
        mItem.setRanges(video, audio);
    }

    private static long lengthOfPart(File part) {
        return part.exists() ? part.length() : 0;
    }

    private static void deletePart(File part) {
        //noinspection ResultOfMethodCallIgnored
        part.delete();
        //noinspection ResultOfMethodCallIgnored
        DownloadOptions.audioIdFile(part).delete();
    }

    @Nullable
    private static MediaFormat findByItag(@Nullable List<MediaFormat> formats, String itag) {
        if (formats == null) {
            return null;
        }
        for (MediaFormat format : formats) {
            if (itag.equals(format.getITag()) && format.getUrl() != null) {
                return format;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------------------------
    // Publish
    // ---------------------------------------------------------------------------------

    private void publish(@Nullable File videoPart, @Nullable File audioPart) throws IOException {
        mItem.state = DownloadItem.STATE_PROCESSING;
        mRegistry.notifyChanged();
        mListener.onProgress(mItem);

        // Issue #317: the finished file is about the parts' size; without room for it the muxer
        // fails late with nothing to show for it, so say so before it starts.
        long needed = (videoPart != null ? videoPart.length() : 0) + (audioPart != null ? audioPart.length() : 0);
        if (DownloadFolder.get(mContext, mItem.isAudioOnly()) == null
                && DownloadRegistry.partsDir(mContext).getUsableSpace() < needed + (16L << 20)) {
            throw new IOException("ENOSPC: " + needed + " bytes needed");
        }

        // MEETUBE(4k-download): VP9 + Opus parts (1440p and up) can only go into WebM.
        boolean webm = DownloadOptions.isWebmFile(videoPart);
        String fileName = DownloadOptions.fileNameFor(mItem.isClip() ? mItem.title + " ("
                        + DownloadOptions.clipLabel(mItem.clipStartMs, mItem.clipEndMs).replace(':', '.') + ")"
                        : mItem.title, mItem.videoId,
                mItem.isAudioOnly() ? "m4a" : webm ? "webm" : "mp4");
        DownloadStorage.Target target = mStorage.create(fileName, mItem.isAudioOnly(), mimeOf(fileName));
        MediaMuxer muxer = null;
        try {
            muxer = mStorage.openMuxer(target, webm);
            long durationMs = MediaMuxHelper.mux(videoPart, audioPart, muxer,
                    mItem.clipStartMs * 1000, mItem.clipEndMs * 1000, mVideoPartStartMs * 1000, mAudioPartStartMs * 1000,
                    (timeUs, durationUs) -> !mItem.cancelRequested);
            muxer.release();
            muxer = null;
            mStorage.commit(target);
            mItem.durationMs = durationMs;
            mItem.outputUri = target.uri.toString();
            mItem.fileName = fileName;
            long size = mStorage.sizeOf(mItem.outputUri);
            if (size > 0) {
                mItem.bytesTotal = size;
                mItem.bytesDone = size;
            }
        } catch (IOException | RuntimeException e) {
            if (muxer != null) {
                try {
                    muxer.release();
                } catch (RuntimeException ignored) {
                }
            }
            mStorage.abandon(target);
            if (mItem.cancelRequested) {
                throw new StreamFetcher.CancelledException();
            }
            throw e instanceof IOException ? (IOException) e : new IOException("mux failed", e);
        }
    }

    static String mimeOf(@Nullable String fileName) {
        if (fileName != null && fileName.endsWith(".webm")) {
            return "video/webm";
        }
        return fileName != null && fileName.endsWith(".m4a") ? "audio/mp4" : "video/mp4";
    }

    /** One copy per video, kind and part: a re-download replaces the earlier file. */
    private void retirePreviousCopies() {
        for (DownloadItem other : mRegistry.items()) {
            if (other != mItem && other.isDone() && other.videoId.equals(mItem.videoId) && other.kind == mItem.kind
                    && other.clipStartMs == mItem.clipStartMs && other.clipEndMs == mItem.clipEndMs) {
                mStorage.delete(other.outputUri);
                if (other.thumbPath != null) {
                    //noinspection ResultOfMethodCallIgnored
                    new File(other.thumbPath).delete();
                }
                mRegistry.remove(other);
            }
        }
    }

    private static void deleteParts(@Nullable File videoPart, @Nullable File audioPart) {
        if (videoPart != null) {
            //noinspection ResultOfMethodCallIgnored
            videoPart.delete();
        }
        if (audioPart != null) {
            //noinspection ResultOfMethodCallIgnored
            audioPart.delete();
            //noinspection ResultOfMethodCallIgnored
            DownloadOptions.audioIdFile(audioPart).delete();
        }
    }
}
