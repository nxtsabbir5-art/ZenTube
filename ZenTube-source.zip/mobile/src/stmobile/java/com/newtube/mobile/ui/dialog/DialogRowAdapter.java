package com.newtube.mobile.ui.dialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.liskovsoft.smartyoutubetv2.common.app.models.playback.ui.OptionCategory;
import com.liskovsoft.smartyoutubetv2.common.app.models.playback.ui.OptionItem;
import com.liskovsoft.smartyoutubetv2.tv.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Flattens a single dialog "level" ({@code List<OptionCategory>}, as handed to
 * {@code AppDialogView.show()}) into a flat list of rows and renders them as a Material
 * list - the touch equivalent of {@code AppPreferenceManager.createPreference()} (which
 * turns the same data model into Leanback {@code Preference} objects).
 *
 * Supported {@link OptionCategory#type} kinds (see {@code AppDialogFragment.onPreferenceDisplayDialog()}
 * for the authoritative TV enumeration this mirrors):
 * <ul>
 *     <li>{@code TYPE_SINGLE_BUTTON} -> one clickable row (plain action item).</li>
 *     <li>{@code TYPE_SINGLE_SWITCH} -> one row with a trailing {@link SwitchMaterial} (boolean setting).</li>
 *     <li>{@code TYPE_RADIO_LIST} -> an optional header row + one radio row per option
 *     (single-select; unlike the TV {@code ListPreference} popup, selections render inline -
 *     no extra navigation level).</li>
 *     <li>{@code TYPE_CHECKBOX_LIST} -> an optional header row + one checkbox row per option
 *     (multi-select).</li>
 *     <li>{@code TYPE_STRING_LIST} -> an optional header row + one plain button row per option
 *     (its callers list actions such as Cancel / Confirm, never a multi-select).</li>
 *     <li>{@code TYPE_LONG_TEXT}/{@code TYPE_CHAT}/{@code TYPE_COMMENTS} -> read-only text
 *     fallback row (chat/comments live-stream panels are deferred to a later wave per
 *     ROADMAP.md; this only guarantees we don't crash on them).</li>
 * </ul>
 */
class DialogRowAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_HEADER = 0;
    private static final int TYPE_BUTTON = 1;
    private static final int TYPE_RADIO = 2;
    private static final int TYPE_CHECKBOX = 3;
    private static final int TYPE_SWITCH = 4;
    private static final int TYPE_TEXT = 5;

    interface Listener {
        void onButtonClicked(OptionItem item);
        void onRadioClicked(OptionCategory category, OptionItem item);
        void onCheckboxClicked(OptionCategory category, OptionItem item);
        void onSwitchToggled(OptionItem item, boolean checked);
    }

    private static final class Row {
        final int viewType;
        final OptionCategory category;
        final OptionItem item;
        final CharSequence title;
        final CharSequence subtitle;
        final boolean checked;

        private Row(int viewType, OptionCategory category, OptionItem item, CharSequence title, CharSequence subtitle, boolean checked) {
            this.viewType = viewType;
            this.category = category;
            this.item = item;
            this.title = title;
            this.subtitle = subtitle;
            this.checked = checked;
        }

        static Row header(CharSequence title) {
            return new Row(TYPE_HEADER, null, null, title, null, false);
        }

        static Row button(OptionItem item) {
            return new Row(TYPE_BUTTON, null, item, item.getTitle(), item.getDescription(), false);
        }

        static Row radio(OptionCategory category, OptionItem item, boolean checked) {
            return new Row(TYPE_RADIO, category, item, item.getTitle(), item.getDescription(), checked);
        }

        static Row checkbox(OptionCategory category, OptionItem item, boolean checked) {
            return new Row(TYPE_CHECKBOX, category, item, item.getTitle(), item.getDescription(), checked);
        }

        static Row switchRow(OptionItem item) {
            return new Row(TYPE_SWITCH, null, item, item.getTitle(), item.getDescription(), item.isSelected());
        }

        static Row text(CharSequence text) {
            return new Row(TYPE_TEXT, null, null, text, null, false);
        }
    }

    private List<Row> mRows = new ArrayList<>();
    private final Context mContext;
    private final Listener mListener;

    DialogRowAdapter(Context context, Listener listener) {
        mContext = context;
        mListener = listener;
    }

    /**
     * @param radioOverrides client-side "currently picked" override per radio category - see
     *                       {@link MobileAppDialogActivity}. TV's {@code ListPreference} only ever
     *                       calls {@code onSelect(true)} on the newly-picked item (never
     *                       {@code onSelect(false)} on the others - see
     *                       {@code AppPreferenceManager.initSingleSelectListPreference}), so the
     *                       sibling items' own {@code isSelected()} never flips. We need this map
     *                       purely to know which row to draw as checked after a tap.
     */
    void submit(List<OptionCategory> categories, Map<OptionCategory, OptionItem> radioOverrides,
                @Nullable CharSequence sheetTitle) {
        mRows = build(categories, radioOverrides, sheetTitle);
        mIconColumn = false;
        for (Row row : mRows) {
            mIconColumn |= row.viewType == TYPE_BUTTON && iconFor(row.title) != 0;
        }
        notifyDataSetChanged();
    }

    /**
     * MEETUBE(menu-sheet): the menu actions' icons, by title (the menus are the TV presenters', which
     * name an action only by its text). A format string ("Remove from %s") matches on its fixed
     * start. An action without one keeps the icon column empty, so the titles stay in one line.
     */
    private static final int[][] ICONS = {
            {R.string.add_video_to_watch_later, R.drawable.ic_menu_watch_later},
            {R.string.dialog_add_to_playlist, R.drawable.ic_player_playlist_add},
            {R.string.add_video_to_new_playlist, R.drawable.ic_mobile_add},
            {R.string.dialog_add_to, R.drawable.ic_player_playlist_add},
            {R.string.dialog_remove_from, R.drawable.ic_menu_delete},
            {R.string.dialog_download, R.drawable.ic_watch_download},
            {R.string.share_link, R.drawable.ic_watch_share},
            {R.string.not_interested, R.drawable.ic_menu_block},
            {R.string.not_recommend_channel, R.drawable.ic_menu_remove},
            {R.string.play_next, R.drawable.ic_player_queue},
            {R.string.add_to_playback_queue, R.drawable.ic_player_queue},
            {R.string.remove_from_playback_queue, R.drawable.ic_menu_delete},
            {R.string.action_playback_queue, R.drawable.ic_player_queue},
            {R.string.dialog_block_channel, R.drawable.ic_menu_block},
            {R.string.dialog_unblock_channel, R.drawable.ic_menu_block},
            {R.string.open_channel, R.drawable.ic_mobile_account},
            {R.string.open_channel_uploads, R.drawable.ic_mobile_account},
            {R.string.subscribe_unsubscribe_from_channel, R.drawable.ic_nav_subscriptions_outline},
            {R.string.subscribe_to_channel, R.drawable.ic_nav_subscriptions_outline},
            {R.string.unsubscribe_from_channel, R.drawable.ic_nav_subscriptions_outline},
            {R.string.remove_from_subscriptions, R.drawable.ic_menu_remove},
            {R.string.open_comments, R.drawable.ic_watch_comment},
            {R.string.open_playlist, R.drawable.ic_player_queue},
            {R.string.playlist_order, R.drawable.ic_mobile_tune},
            {R.string.mark_as_watched, R.drawable.ic_mobile_check},
            {R.string.remove_from_history, R.drawable.ic_mobile_history},
            {R.string.play_video, R.drawable.ic_player_play},
            {R.string.play_from_start, R.drawable.ic_player_replay},
            {R.string.play_video_incognito, R.drawable.ic_settings_privacy},
            {R.string.return_to_background_video, R.drawable.ic_player_background},
            {R.string.action_video_info, R.drawable.ic_settings_about},
            {R.string.set_stream_reminder, R.drawable.ic_menu_bell},
            {R.string.unset_stream_reminder, R.drawable.ic_menu_bell},
            {R.string.pin_channel, R.drawable.ic_menu_pin},
            {R.string.pin_playlist, R.drawable.ic_menu_pin},
            {R.string.unpin_from_sidebar, R.drawable.ic_menu_pin},
            // A section's menu (SectionMenuPresenter) and the account/history/playlist actions.
            {R.string.refresh_section, R.drawable.ic_menu_refresh},
            {R.string.move_section_up, R.drawable.ic_menu_arrow_up},
            {R.string.move_section_down, R.drawable.ic_menu_arrow_down},
            {R.string.rename_section, R.drawable.ic_menu_edit},
            {R.string.rename_playlist, R.drawable.ic_menu_edit},
            {R.string.mark_all_channels_watched, R.drawable.ic_mobile_check},
            {R.string.create_playlist, R.drawable.ic_mobile_add},
            {R.string.save_playlist, R.drawable.ic_player_playlist_add},
            {R.string.remove_playlist, R.drawable.ic_menu_delete},
            {R.string.clear_history, R.drawable.ic_menu_delete},
            {R.string.pause_history, R.drawable.ic_player_pause},
            {R.string.resume_history, R.drawable.ic_player_play},
            {R.string.dialog_account_list, R.drawable.ic_mobile_account},
            {R.string.check_for_updates, R.drawable.ic_mobile_update},
            // A download's own menu (DownloadMenu).
            {R.string.mobile_download_open_folder, R.drawable.ic_menu_folder},
            {R.string.mobile_download_delete, R.drawable.ic_menu_delete},
            {R.string.mobile_download_cancel, R.drawable.ic_sheet_close},
            {R.string.mobile_download_pause, R.drawable.ic_player_pause},
            {R.string.mobile_download_resume, R.drawable.ic_player_play},
            {R.string.mobile_download_retry, R.drawable.ic_player_replay},
    };
    @Nullable private Map<String, Integer> mIcons;
    private final List<String[]> mIconPrefixes = new ArrayList<>(); // {fixed start, drawable id}
    /** Some action in this sheet has an icon: every action row keeps the icon's room. */
    private boolean mIconColumn;

    private int iconFor(@Nullable CharSequence title) {
        if (title == null) {
            return 0;
        }
        if (mIcons == null) {
            mIcons = new java.util.HashMap<>();
            for (int[] pair : ICONS) {
                String text = mContext.getString(pair[0]);
                int format = text.indexOf('%');
                if (format > 0) {
                    mIconPrefixes.add(new String[]{text.substring(0, format), String.valueOf(pair[1])});
                } else {
                    mIcons.put(text, pair[1]);
                }
            }
        }
        String text = title.toString().trim();
        Integer icon = mIcons.get(text);
        if (icon != null) {
            return icon;
        }
        for (String[] prefix : mIconPrefixes) {
            if (text.startsWith(prefix[0])) {
                return Integer.parseInt(prefix[1]);
            }
        }
        return 0;
    }

    private List<Row> build(List<OptionCategory> categories, Map<OptionCategory, OptionItem> radioOverrides,
                            @Nullable CharSequence sheetTitle) {
        List<Row> rows = new ArrayList<>();

        if (categories == null) {
            return rows;
        }

        for (OptionCategory category : categories) {
            if (category == null || category.options == null || category.options.isEmpty()) {
                continue;
            }

            switch (category.type) {
                case OptionCategory.TYPE_SINGLE_BUTTON:
                    rows.add(Row.button(category.options.get(0)));
                    break;
                case OptionCategory.TYPE_SINGLE_SWITCH:
                    rows.add(Row.switchRow(category.options.get(0)));
                    break;
                case OptionCategory.TYPE_RADIO_LIST: {
                    if (category.title != null && !repeatsTitle(category.title, sheetTitle)) {
                        rows.add(Row.header(category.title));
                    }
                    OptionItem override = radioOverrides != null ? radioOverrides.get(category) : null;
                    for (OptionItem item : category.options) {
                        boolean checked = override != null ? item == override : item.isSelected();
                        rows.add(Row.radio(category, item, checked));
                    }
                    break;
                }
                case OptionCategory.TYPE_CHECKBOX_LIST: {
                    if (category.title != null && !repeatsTitle(category.title, sheetTitle)) {
                        rows.add(Row.header(category.title));
                    }
                    for (OptionItem item : category.options) {
                        rows.add(Row.checkbox(category, item, item.isSelected()));
                    }
                    break;
                }
                case OptionCategory.TYPE_STRING_LIST: {
                    // A strings list is plain actions (Cancel / Confirm, a changelog, Restore's backups),
                    // never a multi-select: plain rows, no checkboxes.
                    if (category.title != null && !repeatsTitle(category.title, sheetTitle)) {
                        rows.add(Row.header(category.title));
                    }
                    for (OptionItem item : category.options) {
                        rows.add(Row.button(item));
                    }
                    break;
                }
                case OptionCategory.TYPE_LONG_TEXT: {
                    if (category.title != null && !repeatsTitle(category.title, sheetTitle)) {
                        rows.add(Row.header(category.title));
                    }
                    rows.add(Row.text(category.options.get(0).getTitle()));
                    break;
                }
                case OptionCategory.TYPE_CHAT:
                case OptionCategory.TYPE_COMMENTS: {
                    // TODO Wave N: live chat / comments panel. Read-only stub for now - must not crash.
                    if (category.title != null && !repeatsTitle(category.title, sheetTitle)) {
                        rows.add(Row.header(category.title));
                    }
                    rows.add(Row.text(mContext.getString(R.string.mobile_dialog_unavailable)));
                    break;
                }
            }
        }

        return rows;
    }

    /**
     * NEWTUBE(sheet-title): a header that only repeats the sheet's title ("Playback queue" under
     * "Playback queue", "Video speed" under "Video speed") is left out - a row of height for
     * nothing, and over the landscape player there is little to spare.
     */
    @VisibleForTesting
    static boolean repeatsTitle(CharSequence header, @Nullable CharSequence sheetTitle) {
        return sheetTitle != null && header.toString().trim().equalsIgnoreCase(sheetTitle.toString().trim());
    }

    @Override
    public int getItemViewType(int position) {
        return mRows.get(position).viewType;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        if (viewType == TYPE_HEADER) {
            return new HeaderViewHolder(inflater.inflate(R.layout.item_mobile_dialog_header, parent, false));
        }

        return new RowViewHolder(inflater.inflate(R.layout.item_mobile_dialog_row, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Row row = mRows.get(position);

        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).bind(row);
        } else if (holder instanceof RowViewHolder) {
            int icon = row.viewType == TYPE_BUTTON ? iconFor(row.title) : 0;
            ((RowViewHolder) holder).bind(row, mListener, icon, row.viewType == TYPE_BUTTON && mIconColumn);
        }
    }

    @Override
    public int getItemCount() {
        return mRows.size();
    }

    private static class HeaderViewHolder extends RecyclerView.ViewHolder {
        private final TextView title;

        HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.dialog_header_title);
        }

        void bind(Row row) {
            title.setText(row.title);
        }
    }

    /**
     * Account rows (AccountSelectionPresenter/AccountSettingsPresenter) embed the avatar as an
     * inline {@code ImageSpan} whose drawable keeps its intrinsic bitmap size - full-resolution
     * on a phone, which blew the row up to the avatar's pixel height. Clamp any inline icon to
     * ~1.4x the row's text size (roughly the line box, like an emoji). TV renders these rows with
     * Leanback (which sizes icons itself), so this stays a mobile-renderer concern.
     */
    private static CharSequence sizeInlineIcons(CharSequence text, TextView target) {
        if (!(text instanceof android.text.Spanned)) {
            return text;
        }

        android.text.Spanned spanned = (android.text.Spanned) text;
        android.text.style.ImageSpan[] spans =
                spanned.getSpans(0, spanned.length(), android.text.style.ImageSpan.class);
        if (spans.length == 0) {
            return text;
        }

        int size = Math.round(target.getTextSize() * 1.4f);
        for (android.text.style.ImageSpan span : spans) {
            android.graphics.drawable.Drawable drawable = span.getDrawable();
            if (drawable != null) {
                drawable.setBounds(0, 0, size, size);
            }
        }

        return text;
    }

    private static class RowViewHolder extends RecyclerView.ViewHolder {
        private final android.widget.ImageView icon;
        private final TextView title;
        private final TextView subtitle;
        private final RadioButton radio;
        private final CheckBox checkbox;
        private final SwitchMaterial switchControl;

        RowViewHolder(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.dialog_row_icon);
            title = itemView.findViewById(R.id.dialog_row_title);
            subtitle = itemView.findViewById(R.id.dialog_row_subtitle);
            radio = itemView.findViewById(R.id.dialog_row_radio);
            checkbox = itemView.findViewById(R.id.dialog_row_checkbox);
            switchControl = itemView.findViewById(R.id.dialog_row_switch);
        }

        void bind(Row row, Listener listener, int iconRes, boolean iconColumn) {
            title.setText(sizeInlineIcons(row.title, title));
            if (iconRes != 0) {
                icon.setImageResource(iconRes);
            } else {
                icon.setImageDrawable(null);
            }
            icon.setVisibility(iconColumn ? View.VISIBLE : View.GONE);

            if (row.subtitle != null && row.subtitle.length() > 0) {
                subtitle.setText(row.subtitle);
                subtitle.setVisibility(View.VISIBLE);
            } else {
                subtitle.setVisibility(View.GONE);
            }

            radio.setVisibility(View.GONE);
            checkbox.setVisibility(View.GONE);
            switchControl.setVisibility(View.GONE);
            switchControl.setOnCheckedChangeListener(null);
            itemView.setOnClickListener(null);

            boolean clickable = row.viewType != TYPE_TEXT;
            itemView.setClickable(clickable);
            itemView.setFocusable(clickable);
            title.setAlpha(row.viewType == TYPE_TEXT ? 0.85f : 1f);

            switch (row.viewType) {
                case TYPE_BUTTON:
                    itemView.setOnClickListener(v -> listener.onButtonClicked(row.item));
                    break;
                case TYPE_RADIO:
                    radio.setVisibility(View.VISIBLE);
                    radio.setChecked(row.checked);
                    itemView.setOnClickListener(v -> listener.onRadioClicked(row.category, row.item));
                    break;
                case TYPE_CHECKBOX:
                    checkbox.setVisibility(View.VISIBLE);
                    checkbox.setChecked(row.checked);
                    itemView.setOnClickListener(v -> listener.onCheckboxClicked(row.category, row.item));
                    break;
                case TYPE_SWITCH:
                    switchControl.setVisibility(View.VISIBLE);
                    switchControl.setChecked(row.checked);
                    switchControl.setOnCheckedChangeListener(
                            (buttonView, isChecked) -> listener.onSwitchToggled(row.item, isChecked));
                    itemView.setOnClickListener(v -> switchControl.setChecked(!switchControl.isChecked()));
                    break;
                case TYPE_TEXT:
                default:
                    // Read-only - no click handling.
                    break;
            }
        }
    }
}
