package com.newtube.mobile.downloads;

import androidx.annotation.Nullable;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.UUID;

/**
 * One entry of the Downloads list, persisted by {@link DownloadRegistry}.
 *
 * <p>The stream URLs are deliberately NOT persisted: googlevideo links expire after a few hours
 * and are bound to the network they were minted on. A job that outlives the process (or a Retry)
 * resolves the itags again from a fresh format info.
 */
public final class DownloadItem {
    public static final int STATE_QUEUED = 0;
    public static final int STATE_DOWNLOADING = 1;
    public static final int STATE_PROCESSING = 2;
    public static final int STATE_DONE = 3;
    public static final int STATE_FAILED = 4;
    /** Stopped by the user (or by a process death) with its part files kept: Resume goes on from there. */
    public static final int STATE_PAUSED = 5;

    public final String id;
    public final String videoId;
    public final String title;
    @Nullable public final String author;
    @Nullable public final String thumbUrl;
    /** {@link DownloadOption#KIND_VIDEO} or {@link DownloadOption#KIND_AUDIO}. */
    public final int kind;
    @Nullable public final String qualityLabel;
    @Nullable public final String videoItag;
    @Nullable public final String audioItag;
    /**
     * Which language variant of {@link #audioItag} was picked ({@link DownloadOptions#audioTrackKey}):
     * every dub shares the itag, so a re-resolve must match this too, and a kept audio part is
     * only resumed when it belongs to the same track. Null = not recorded (items saved before
     * 1.15.1): those re-resolve to the original track and restart their audio part.
     */
    @Nullable public volatile String audioTrack;
    public final long createdAt;
    /** A part of the video only (issue #241): start and end in ms; both 0 = the whole video. */
    public volatile long clipStartMs;
    public volatile long clipEndMs;
    /** MEETUNE: downloaded from MeeTune: listed on its Library's Downloads, not on MeeTube's. */
    public volatile boolean song;

    public volatile int state = STATE_QUEUED;
    public volatile long bytesDone;
    public volatile long bytesTotal = -1;
    @Nullable public volatile String outputUri;
    @Nullable public volatile String fileName;
    @Nullable public volatile String thumbPath;
    public volatile long durationMs;
    /** Short, user-facing failure reason (already localized) or null. */
    @Nullable public volatile String error;

    // Transient: the URLs of the enqueue moment, reused while they are fresh.
    @Nullable public transient volatile String videoUrl;
    @Nullable public transient volatile String audioUrl;
    public transient volatile long videoLength = -1;
    public transient volatile long audioLength = -1;
    /** The streams' header and index byte ranges ("0-740"): a part download fetches only its bytes. */
    @Nullable public transient volatile String videoInit;
    @Nullable public transient volatile String videoIndex;
    @Nullable public transient volatile String audioInit;
    @Nullable public transient volatile String audioIndex;
    public transient volatile boolean cancelRequested;
    public transient volatile boolean pauseRequested;

    public DownloadItem(String id, String videoId, String title, @Nullable String author,
                        @Nullable String thumbUrl, int kind, @Nullable String qualityLabel,
                        @Nullable String videoItag, @Nullable String audioItag, long createdAt) {
        this.id = id;
        this.videoId = videoId;
        this.title = title;
        this.author = author;
        this.thumbUrl = thumbUrl;
        this.kind = kind;
        this.qualityLabel = qualityLabel;
        this.videoItag = videoItag;
        this.audioItag = audioItag;
        this.createdAt = createdAt;
    }

    public static DownloadItem create(String videoId, String title, @Nullable String author,
                                      @Nullable String thumbUrl, DownloadOption option) {
        DownloadItem item = new DownloadItem(UUID.randomUUID().toString(), videoId, title, author, thumbUrl,
                option.kind, option.qualityLabel,
                option.video != null ? option.video.getITag() : null,
                option.audio != null ? option.audio.getITag() : null,
                System.currentTimeMillis());
        item.videoUrl = option.video != null ? option.video.getUrl() : null;
        item.audioUrl = option.audio != null ? option.audio.getUrl() : null;
        item.audioTrack = DownloadOptions.audioTrackKey(option.audio);
        item.videoLength = DownloadOptions.lengthOf(option.video);
        item.audioLength = DownloadOptions.lengthOf(option.audio);
        item.setRanges(option.video, option.audio);
        item.bytesTotal = option.totalBytes;
        return item;
    }

    void setRanges(@Nullable com.liskovsoft.mediaserviceinterfaces.data.MediaFormat video,
                   @Nullable com.liskovsoft.mediaserviceinterfaces.data.MediaFormat audio) {
        videoInit = video != null ? video.getInit() : null;
        videoIndex = video != null ? video.getIndex() : null;
        audioInit = audio != null ? audio.getInit() : null;
        audioIndex = audio != null ? audio.getIndex() : null;
    }

    public boolean isAudioOnly() {
        return kind == DownloadOption.KIND_AUDIO;
    }

    public boolean isClip() {
        return clipEndMs > clipStartMs;
    }

    public boolean isActive() {
        return state == STATE_QUEUED || state == STATE_DOWNLOADING || state == STATE_PROCESSING;
    }

    public boolean isDone() {
        return state == STATE_DONE;
    }

    public boolean isFailed() {
        return state == STATE_FAILED;
    }

    public boolean isPaused() {
        return state == STATE_PAUSED;
    }

    /** MEETUBE(issue #265): bytes a second while downloading, smoothed; 0 until known. Not saved. */
    public transient volatile float bytesPerSec;
    private transient long mSpeedAtMs;
    private transient long mSpeedBytes;

    /** Called with each progress report; a new rate every second, eased so the text doesn't jump. */
    void sampleSpeed(long nowMs) {
        long done = bytesDone;
        long elapsed = nowMs - mSpeedAtMs;
        if (mSpeedAtMs == 0 || elapsed > 5000 || done < mSpeedBytes) { // first, after a pause, a new part
            mSpeedAtMs = nowMs;
            mSpeedBytes = done;
            if (elapsed > 5000) bytesPerSec = 0f;
            return;
        }
        if (elapsed < 1000) return;
        float now = (done - mSpeedBytes) * 1000f / elapsed;
        bytesPerSec = bytesPerSec == 0f ? now : bytesPerSec * 0.7f + now * 0.3f;
        mSpeedAtMs = nowMs;
        mSpeedBytes = done;
    }

    /** Seconds left at the current rate, or -1 while it isn't known. */
    public long secondsLeft() {
        long total = bytesTotal;
        float rate = bytesPerSec;
        if (total <= 0 || rate < 1f || bytesDone >= total) return -1;
        return (long) Math.ceil((total - bytesDone) / rate);
    }

    /** 0..100, or -1 while the total is unknown. */
    public int progressPercent() {
        long total = bytesTotal;
        if (total <= 0) {
            return -1;
        }
        return (int) Math.min(100, bytesDone * 100 / total);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject json = new JSONObject();
        json.put("id", id);
        json.put("videoId", videoId);
        json.put("title", title);
        json.putOpt("author", author);
        json.putOpt("thumbUrl", thumbUrl);
        json.put("kind", kind);
        json.putOpt("qualityLabel", qualityLabel);
        json.putOpt("videoItag", videoItag);
        json.putOpt("audioItag", audioItag);
        json.putOpt("audioTrack", audioTrack);
        json.put("createdAt", createdAt);
        if (isClip()) {
            json.put("clipStartMs", clipStartMs);
            json.put("clipEndMs", clipEndMs);
        }
        json.put("state", state);
        json.put("bytesDone", bytesDone);
        json.put("bytesTotal", bytesTotal);
        json.putOpt("outputUri", outputUri);
        json.putOpt("fileName", fileName);
        json.putOpt("thumbPath", thumbPath);
        json.put("durationMs", durationMs);
        json.putOpt("error", error);
        if (song) json.put("song", true);
        return json;
    }

    public static DownloadItem fromJson(JSONObject json) throws JSONException {
        DownloadItem item = new DownloadItem(
                json.getString("id"), json.getString("videoId"), json.optString("title", ""),
                optString(json, "author"), optString(json, "thumbUrl"), json.optInt("kind", DownloadOption.KIND_VIDEO),
                optString(json, "qualityLabel"), optString(json, "videoItag"), optString(json, "audioItag"),
                json.optLong("createdAt", 0));
        item.audioTrack = optString(json, "audioTrack");
        item.clipStartMs = json.optLong("clipStartMs", 0);
        item.clipEndMs = json.optLong("clipEndMs", 0);
        item.state = json.optInt("state", STATE_FAILED);
        item.bytesDone = json.optLong("bytesDone", 0);
        item.bytesTotal = json.optLong("bytesTotal", -1);
        item.outputUri = optString(json, "outputUri");
        item.fileName = optString(json, "fileName");
        item.thumbPath = optString(json, "thumbPath");
        item.durationMs = json.optLong("durationMs", 0);
        item.error = optString(json, "error");
        item.song = json.optBoolean("song", false);
        return item;
    }

    @Nullable
    private static String optString(JSONObject json, String key) {
        return json.isNull(key) ? null : json.optString(key, null);
    }
}
