<div align="center">

# MeeTube Changelog

Every MeeTube release, newest first.<br>
✨ New &nbsp;·&nbsp; 🛠️ Changed &nbsp;·&nbsp; 🐛 Fixed

</div>


| Version | Released | Highlights |
| :-- | :-- | :-- |
| [**3.6.0** Sakura](#360-sakura) | 2026-11-24 | Android Auto |
| [**3.5.8** Amber](#358-amber) | 2026-11-21 | Karaoke |
| [**3.5.5** Hyper](#355-hyper) | 2026-11-17 | Automix |
| [**3.5.2** Slash](#352-slash) | 2026-11-17 | Spatial |
| [**3.5.0** Drago](#350-drago) | 2026-11-16 | MeeTune |
| [**3.4.2** Severus](#342-severus) | 2026-11-15 | Stable |
| [**3.4.0** Bleach](#340-bleach) | 2026-11-12 | YouTube mode |
| [**3.3.7** Melmo](#337-melmo) | 2026-11-12 | Connected |
| [**3.3.5** Sentinel](#335-sentinel) | 2026-11-08 | Immersive |
| [**3.3.1** Pluto](#331-pluto) | 2026-11-04 | Tuned |
| [**3.3.0** Glitch](#330-glitch) | 2026-11-03 | Polished |
| [**3.2.7** HotLight](#327-hotlight) | 2026-11-02 | Lighter |
| [**3.2.5** Plazma](#325-plazma) | 2026-11-01 | Smoother |
| [**3.2.3** Mirage](#323-mirage) | 2026-10-31 | Pick your spinner and icon, Shorts autoscroll, a mini player that rides the bottom bar |
| [**3.2.1** Sublime](#321-sublime) | 2026-10-28 | Shorts open instantly, a SponsorBlock skip pill, transcripts for songs without lyrics |
| [**3.2.0** Rebirth](#320-rebirth) | 2026-10-28 | MeTube is now MeeTube, downloads up to 4K, GlowFlow everywhere |
| [**3.1.8** Lora](#318-lora) | 2026-10-27 | Live rings, a playful Customization page, zoom anywhere |
| [**3.1.7** Clozone](#317-clozone) | 2026-10-26 | Your bars your way, live chat beside the video, share from the second |
| [**3.1.5** Orizon](#315-orizon) | 2026-10-25 | A new You page, More videos in fullscreen, HDR video |
| [**3.1.1** Spectre](#311-spectre) | 2026-10-22 | MeeTube on Android TV, Shorts quality, tablet fixes |
| [**3.1.0** DoomsSlay](#310-doomsslay) | 2026-10-22 | Actions in fullscreen, a video box that fits, quicker Shorts |
| [**3.0.5**](#305) | 2026-10-21 | MeeTube in Traditional Chinese, Shorts on channels, search chips |
| [**3.0.1**](#301) | 2026-10-19 | YouTube's search filters, Shorts in search, a real channel page |
| [**3.0.0**](#300) | 2026-10-19 | Your own bottom bar, three app icons, a truthful quality label |
| [**2.9.9**](#299) | 2026-10-18 | Shorts in picture-in-picture, channel pictures, a new icon |
| [**2.9.8**](#298) | 2026-10-17 | Home filters, sleep timer, steadier background play |
| [**2.9.6**](#296) | 2026-10-15 | Hotfix |
| [**2.9.5**](#295) | 2026-10-15 | Headphones on the mini player, iOS-style switches |
| [**2.9.3**](#293) | 2026-10-15 | Lyrics providers, smoother comments and fullscreen |
| [**2.9.2**](#292) | 2026-10-14 | Lyrics, liquid glass player, Description panel |
| [**2.8.0**](#280) | 2026-10-13 | Search tab and filters, Shorts edge to edge, floating mini player |
| [**2.5.7**](#257) | 2026-10-09 | Music button opens your music app |
| [**2.5.6**](#256) | 2026-10-09 | Picture-in-picture every time, and a Music button |
| [**2.5.1**](#251) | 2026-10-09 | Audio only, new icon and fixes |
| [**2.5.0**](#250) | 2026-10-09 | Glass and quicker Shorts |
| [**2.0.2**](#202) | 2026-10-08 | Vertical fullscreen |
| [**2.0.1**](#201) | 2026-10-07 | Feel |
| [**2.0.0**](#200) | 2026-10-07 | Liquid Glass |
| [**1.5.0**](#150) | 2026-10-07 | Shorts |
| [**1.0.0**](#100) | 2026-10-07 | Floating Glass |


## 3.6.0 Sakura

> **Android Auto**<br>
> 📅 2026-11-24 · closes #253, #300, #303, #304, #305, #308, #309, #310, #313, #314, #317, #318 and #320

### ✨ Highlights

- **MeeTune in your car with Android Auto:** Home, Made for you, Recents and Library tabs with rounded covers, your liked songs, downloads and cached songs offline, voice search and lyrics. The car player has a heart, shuffle, repeat, radio and close. Connect to car in the MeeTune player's menu moves the song you're playing to the car, and Settings > Car has a Show MeeTune in Android Auto row with the steps to turn it on (#253).
- **MeeTune Home like YouTube Music:** every shelf loads now (Trending, New releases, Mixed for you and more) with its chips on top, and more come as you scroll (#304).
- **History syncs with YouTube Music** both ways, with a switch in MeeTune settings to pause it (#305).
- **A real Up next queue:** a full page with a search box, Now playing, your Play next songs and AutoPlay's radio. Drag a song to move it, tap X to drop it.
- **MeeTune keeps playing in MeeTube:** switch apps and the song stays on in a frosted pill you can drag anywhere and swipe off any edge to close.
- **Continue from the Home preview:** tapping a Home video while its preview plays picks up where the preview was. Turn it off in Settings > Player (#320).
- **Download on Wi-Fi only** in Settings > Downloads. On mobile data downloads wait, and one that's running pauses and resumes on Wi-Fi (#318).

### 🎵 MeeTune

- Hold MeeTune's logo for a greeting with your listening stats, a sleep timer and a settings shortcut. MeeTube and MeeTune time are counted separately.
- Covers load about 4x faster, and shelves scroll smoother.
- Spatial sound has a Wide mode, now the default, for a crisper and wider sound on headphones.
- Big playlists show every track, not just the first 100, and search inside them finds them all (#308).
- Karaoke keeps removing vocals after the phone falls behind once, and no longer runs the phone hot (#314).
- Settings open as a list of sections like MeeTube's, each on its own page.
- Home's chips slide away on scroll and come back from a little arrow by the heart, and the top bar matches MeeTube Home in YouTube mode.

### New

- Custom app name in Settings > Customization > Tabs and bars, up to 10 characters, in MeeTube and MeeTune.
- Your font file in Font settings: pick any TTF or OTF from your phone for the whole app.
- Landscape player controls at the screen corners over the black bars, like YouTube (#303).
- Ambient mode covers the whole tablet watch page.
- Channels mentioned in a description open in the app when you tap an @name or a channel link (#310).
- MeeTube in Vietnamese.

### Changed

- Auto downloads keep going in the background, and downloads cut off by the app being killed resume on their own (#300).
- Download errors say why, and a check before saving catches a full phone early (#317).
- Subs filters follow the Chips style, so they stay glass pills in OG Mode.
- Search results get a faded blur under the top bar.

### Fixed

- Shorts on Subs is no longer empty (#309).
- Channel sort no longer does nothing sometimes, and it's hidden on the Shorts tab where sorting emptied it.
- Unmuting a feed preview pauses MeeTune instead of playing over it.
- The mini player no longer jumps after a swipe down in YouTube mode.

### 💬 Community

MeeTube has a Telegram group now. Come say hi, get help, share ideas and hear about new releases first: [MeeTube Community](https://t.me/+fLlQpFKSfqdhMGZl) (#313).

### Thanks

Thanks to everyone who reports issues, and in this release to @PravinGavand, @MAKAKAIglitch, @VedantS5, @ra-rear, @kadheerk49, @SneednFeed88, @nouse8192-tech, @dhanunjay333i-cyber, @itsstryxx, @mygtvact, @mahidulmahin80-cloud and @socsieuquaypro-sketch for the Vietnamese translation.

## 3.5.8 Amber

> **Karaoke**<br>
> 📅 2026-11-21 · closes #263, #280, #281, #284, #285, #287, #292, #295 and #296

### ✨ Highlights

- **MeeTune AI Karaoke (beta):** removes the vocals from the playing song right on your phone with the YkAI Model, a one time 39 MB download after asking, so the APK stays the same size. Turn it on in the MeeTune player menu and delete the model anytime in MeeTune settings (#281).
- **MeeTuneMix:** Automix is now MeeTuneMix. The ending song fades out where its music ends and the next one fades in slowly, with no volume jumps, cut vocals or long wait before the switch. The Beat This model is gone, so the APK is back to its old size.
- **Spotify in MeeTune:** sign in to Spotify for its Canvas loops behind the player and import your Spotify playlists. Spotify sits under Add-ons in MeeTune settings.
- **A library with no account:** make playlists, save and pin albums and playlists, and export or import them as a file, so songs go into playlists without signing in (#280).
- **Your phone's Dolby Atmos:** MeeTube hands its audio to the phone's own sound engine, so Dolby Atmos and sound effects from the phone's settings work on songs and videos, through crossfades too. Dolby tracks play on phones without a Dolby decoder, and MeeTune shows DOLBY or DOLBY ATMOS while one plays (#284).

### 🎵 MeeTune

- Canvas also plays animated covers from Apple Music and Tidal, and short silent loops from a song's official music video, fetched once and played from the phone.
- A play mode button (Autoplay, Shuffle, Repeat one, Off) that songs follow instead of MeeTube's Autoplay.
- The focus arrow under the controls hides the volume and song pill and makes the sung line big.
- A search next to the Library heading finds playlists by name, and YouTube Music playlists in the Library can be renamed or deleted with a long press.
- New playlist and Rename open on blur glass like the other MeeTune popups, and Create waits for a name.
- Tapping the ticked account in MeeTune's menu unticks it, so MeeTune runs without an account.
- Settings are regrouped, and every setting has a small i that explains what it does.
- Smoother volume slider, sliders pop while you drag them, and Lyrics are coming shows while lyrics load.
- The 256 kbps AAC track (Premium accounts) plays instead of Opus when YouTube sends it.

### New

- Pinch zoom on the player goes up to 8x like the YouTube app (#296).
- Channel sort is a Sort pill next to Posts and shows the order you picked for each tab (#295).
- The greeting shows a classic quote under it, a different one every time it opens.

### Changed

- Taps light up a soft glass pill instead of the old ripple on rows, glass buttons, cards and chips, and Settings explanations sit behind a small i after the title.
- The Add a comment bar stays at the bottom of the comments while you scroll, and the comment box opens on frosted glass and glides up with the keyboard.
- Shorts show whole by default instead of zoomed in, and pinch or the Zoom setting works on them.
- Confirm and Cancel in popups like Remove playlist are plain rows again instead of checkboxes.
- The Dolby switch is gone from MeeTune settings, since YouTube Music songs are stereo only.

### Fixed

- Live streams no longer freeze the app and load forever when the stream buffer setting is off (#292).
- Songs no longer go silent in the background after a crossfade or MeeTuneMix switch on Android 17 (#285).
- MeeTune no longer says Could not reach YouTube Music, or fails to sign in, when the phone's language is set to a region YouTube doesn't support, like English (Saudi Arabia) (#263).
- Ambient mode works again on live streams and other 60 fps or HDR videos.
- Chips style and Tab glow no longer snap back when OG Mode is on. OG Mode only sets them until you pick your own (#287).
- Long press on phone playlists works again in the Library grid.
- The Lyrics button no longer looks zoomed.
- The comments panel no longer shows rounded corners and a line at the bottom.

### Thanks

Thanks to everyone who reports issues, and in this release to @mohamedalim26, @kadheerk49, @dhanunjay333i-cyber, @harshXigll, @SneednFeed88, @SpadezOfSpadez, @delgadoleonard555-jpg and @Rex000.

## 3.5.5 Hyper

> **Automix**<br>
> 📅 2026-11-17 · closes #256, #270, #271, #272, #273, #275, #278 and #279

### ✨ Highlights

- **Automix (beta) in MeeTune:** songs mix like a DJ. The next one comes in on the beat with its tempo matched, past its silent intro, and the two swap bass on a bar line. Turn it on under Crossfade in MeeTune settings (#279).
- **Speed and quality in fullscreen:** two buttons beside the fullscreen button show the speed and the quality playing and open their menus on tap. Turn them off in Customize > Player buttons (#271).
- **Dubs in your language:** Settings > Audio preferences > Audio language plays a video's dub in MeeTube's or Android's language, and the original when there is none (#256).
- **Volume boost you can hear:** each doubling of Player volume adds +10 dB, with a speaker icon whose waves light up as you slide (#272).
- **Pick a font:** Customization > Font sets Google Sans, Minecraft or Vazirmatn across the whole app (Android 8 and up).

### 🎵 MeeTune

- Its own Volume, a crossfade slider that shows the two songs' waves overlapping, and a Bit-perfect USB DAC switch (Android 14 and up).
- The next song starts the moment a song ends, so crossfade blends the two songs again instead of fading into a gap.
- Downloads show their percent, speed and time left on a frosted cover, live.
- Black and white covers get a soft white glow.
- Tap the countdown to see the song's full length for 10 seconds.
- Live stations show LIVE with a full bar.
- Back on Home leaves the app with the song playing, and Previous only goes back to a song.

### New

- Swiping up out of the upright fullscreen follows your finger: the video shrinks and the title and comments come up under it.
- Video downloads show their progress and speed on the thumbnail.

### Changed

- Play, pause, next and previous have rounded corners like MeeTune's controls.
- Player volume has its own card in Settings, and Audio quality is now Audio preferences.
- The mini player's buttons fade in out of a light blur once it lands.
- A short with its comments open loops instead of scrolling away, and a tap shows only play, the time and the seek bar.

### Fixed

- Opening any video no longer crashes on Android 8 and 9 (#270).
- Playing a video no longer crashes on some phones (#275).
- Shorts no longer pause on their own while scrolling fast (#278).
- Minimizing lands the mini player exactly in its corner, and a card dragged to another corner stays there after picture-in-picture (#273).
- MeeTune songs no longer show up in MeeTube's History and mini player.
- The page under the video no longer stays blank after leaving fullscreen.
- Swiping away a song's mini player just closes it instead of opening MeeTube Home.
- The lyric line above the bar no longer flashes when switching songs.

### Thanks

Thanks to everyone who reports issues, and in this release to @y4hya3, @MuntasirTonmoy, @MAKAKAIglitch, @sahidur2007, @dhanunjay333i-cyber, @fcaballeros1303-netizen and @pambat.

## 3.5.2 Slash

> **Spatial**<br>
> 📅 2026-11-17 · closes #254, #258, #259, #262 and #264

### ✨ Highlights

- **MeeTune sounds bigger:** Spatial sound with a real head model (MIT KEMAR), a Cinema level with deeper bass, and Head tracking on Android 13+ through your phone's own spatial audio.
- **More from MeeTune's sound:** Dolby, headphone correction, crossfade between songs, quality per Wi-Fi and mobile data, and covers that glow (#262, #264).
- **Speed to the hundredth:** Playback speed has a slider and - / + for any speed from 0.25x to 4x in 0.01 steps, and songs keep their own speed (1x unless you pick one), whatever a video plays at.
- **Smoother 60 fps:** 60 fps videos no longer stutter in the watch page and fullscreen (#259).

### New

- Downloads show their speed and time left, like 2.4 MB/s · 1:23 left.
- A Short turned sideways shows whole at 9:16, with sharp edges over the blurred sides.
- Double tap a Short to like it with a white thumb that springs in over a glow, and double tap again to unlike it.
- On a tablet, Home and the other feeds show 4 videos a row sideways, and the watch page keeps Up next beside the video instead of going fullscreen (#254).
- MeeTune's player menu has Playback speed.

### Changed

- Every back button in MeeTube and MeeTune is a thin chevron.
- MeeTune pages and its player run up under the status bar, frosted there like MeeTube's.
- The mini player's play and pause bloom a glow in the cover's colour.
- More > Zoom shows the zoom mode in use (Stretch, Fit width and others).
- In a grid of 3 or more columns, search shows Shorts as one row of tall cards.

### Fixed

- The double tap's time pill no longer stays stuck on the video.
- A picker over the fullscreen video keeps its height once its list is scrolled, instead of jumping under the finger (#258).
- The Shorts like and comment column stays below the top buttons on short screens.
- The swipe down from a 60 fps or HDR video no longer jerks on its first move.

## 3.5.0 Drago

> **MeeTune**<br>
> 📅 2026-11-16 · closes #239, #247 and #250

### ✨ Highlights

- **MeeTune, a big update (beta, still in development):** MeeTube now has a music side of its own. Tap the logo on Home to switch: YouTube Music's Home, Explore, Library and Search, with albums, artists, playlists and moods, a full player with synced lyrics, and settings of its own.
- **Smoother all round:** the mini player folds without a stutter, switching the equalizer on or off no longer drops the sound, glass frosts whatever scrolls under it, and picture-in-picture from the mini player works again on Android 17.
- **A bell on every channel:** turn new-upload notifications on or off per channel, right beside Subscribed. It rings with a little swing and chime, quiet on silent (#239).
- **Bars that stay put:** Fixed Top Bar and Fixed Nav Bar in Customization > Bars keep the bars on screen while you scroll, off by default.

### 🎵 MeeTune (beta)

- Plays like a music app: the next song and Up next come from the YouTube Music radio, your Play next and queue come first, and the radio never bounces back to a song it just played.
- Skips are instant: the next song is saved to your phone while the current one plays, and Library > Cached songs plays every cached song with no network.
- Downloaded songs and their lyrics play offline, from MeeTune's own Downloads page in Library.
- A History of its own, kept on your phone, and your songs no longer fill MeeTube's watch history.
- One frosted song menu everywhere: Like, Dislike, Share, Start radio, Play next, Add to queue, Download, Open album or artist, Song info and more.
- The player: a heart that likes the song on YouTube Music, big glowing controls, a cover that melts into the background, moving covers for some songs, and a pill with the format and your headset's name.
- Search looks like YouTube Music's, with Songs, Videos, Albums, Artists and Playlists chips, a Top result and the E badge.
- The MeeTune Equalizer shapes only your songs: a Dynamic tone pad or Manual bands, balance, and the phone's system equalizer.
- MeeTube and MeeTune keep separate players: switching pauses the other side, and each one waits where you left it.
- It's a beta, so some things may still change or break. Tell me in Issues and I'll fix them fast.

### 📣 A note from me

- **If MeeTune made your playlist sing, maybe treat me to a coffee? ☕** Totally optional and always appreciated: sudo brew coffee in About, [Buy me a coffee](https://buymeacoffee.com/yashwynth), or UPI `yashwynth@slc` in India. Every star, issue and kind word keeps the late nights going. Thank you for being here. ❤️

### New

- Settings > Notifications: how often to check (15 min to 6 h, now hourly by default), every channel's bell in one list, and Run in the background for phones that stop apps (Infinix, Xiaomi and others).
- Auto download's Channels picker lists your subscriptions when signed in (#247).
- Separate download folders for Video and Music.
- Equalizer presets are glass pills, and a rotate button stands the bands upright side by side.

### Changed

- YouTube mode is now called OG Mode.
- The equalizer, quality, speed and headphone correction sheets, text-entry dialogs and the see-through settings sheets are frosted glass like the rest.
- On the dark theme, dialogs and every sheet are dark tinted glass instead of milky grey.
- Home's chips fold arrow sits plain on the top bar.
- Russian refreshed from top to bottom by @MAKAKAIglitch (#255).

### Fixed

- The search bar and the page's glass pills no longer show sharp text through them while you scroll (#250).
- The mini card comes back where you dragged it after picture-in-picture or audio-only.
- Saving a playlist or Mix card to a playlist saves all its videos, not only the first.
- The fullscreen button no longer shows an octagon through its glass.

## 3.4.2 Severus

> **Stable**<br>
> 📅 2026-11-15 · closes #92, #93, #131, #237, #238, #241, #242 and #244

### ✨ Highlights

- **Stable build:** after Android clears MeeTube in the background, the player comes back right where you left off instead of a blank video or 0:00, and the mini player and picture-in-picture behave on return.
- **Timer:** hold the logo for a small frosted Timer (15, 25, 45, 60 min, or hold it to type any length). When it runs out MeeTube asks "Are ya winning, son?" and sends you back to focus, or gives you 5 more min.
- **Battery Saver:** with the phone's Battery Saver on, MeeTube offers once to turn off animations and frosted glass, and Settings > Battery Saver has a switch to turn them off any time (#93).
- **Your stats:** holding the logo also shows today's time in MeeTube, watch time, videos and the last 7 days as bars, kept only on your phone.

### 📣 A note from me

- **MeeTube TV now lives in its own repo, give it a try on your TV whenever you like:** [yashoncode/meetube-tv](https://github.com/yashoncode/meetube-tv) has its downloads, changelog and issues. Settings > About > Install on my TV sends it over from your phone. No rush at all, only if you feel like it.
- **Love MeeTube? A coffee keeps the late nights going, totally optional:** sudo brew coffee in About, [Buy me a coffee](https://buymeacoffee.com/yashwynth), or UPI `yashwynth@slc` in India. Thank you for every star, issue and kind word.

### New

- Download a part of a video: pick start and end frames on a trim slider, and MP4 parts fetch only their own bytes (#241).
- A layout for every page: pick the video layout for Home, Subscriptions, playlists, channels, search and Up next, with Customization split into five pages (#92).
- Save other people's playlists to You (and your account's library when signed in), with Saved playlists and Pinned channels on glass cards under History (#242).
- 240p and 144p join the default quality choices for Wi-Fi, mobile data and Shorts, for limited data plans (#244).
- About ends with a MeeTube TV card that leans with your phone, with Install on my TV and a link to its repo.
- Home's chip segments are jelly: they swell under your finger, stretch toward a new pick and wobble back. Hold and drag the lens, and the row glides along at either end.

### Changed

- Install on TV downloads MeeTube TV from its own repo, and the steps name the right TV menus.
- Up next rows match the other lists: a three-line title, two lines of details and the overflow button (#131).
- Chapters upright open in the panel under the video, like the transcript, and the video still takes taps (#238).
- Menus follow a finger dragged down and close or spring back on release.

### Fixed

- Pull to refresh on Gaming, News, Music and the other Home topics now brings new videos (#185).
- News no longer shows the same Shorts row twice.
- The segment pill no longer jumps on refresh or flickers when you switch back and forth.
- The drag lens stays whole at either end of the segments.
- The No connection pill fits its text in fullscreen, and Watch later no longer adds videos twice (#237).

### Thanks

Thanks to everyone who reports issues, tests builds and shares MeeTube with friends.

## 3.4.0 Bleach

> **YouTube mode**<br>
> 📅 2026-11-12 · closes #193, #220, #233, #235 and #236

### ✨ Highlights

- **YouTube mode:** one switch in Settings > Customization > Look makes MeeTube feel like YouTube. The bottom bar sits flat on the bottom edge on frosted glass, Search moves up to the top bar, Home's chips become text tabs and every video card gets sharp corners.
- **Any accent colour:** pick a Custom colour with a full colour picker (hue, saturation, brightness, 16 quick picks or a hex code), and the whole app follows it.
- **Settings revamp:** Settings sit on grouped glass cards with seven card styles to choose from, pages frost in and out, and Customization shows a picture for more of its options.
- **Hyped:** YouTube's Charts in Explore (or as a bottom bar tab), every video ranked on its thumbnail, and a Hype this video card beside the comments on the watch page.
- **New uploads in your notifications:** new videos from your subscriptions show up in the notification shade, with or without an account. Settings > General > Notify about new uploads turns it off (#220).
- **Polish and Brazilian Portuguese:** MeeTube now speaks both in full, every screen and setting translated.
- **Magic under the hood:** seeking shows the real frame in the video's own quality, a Most replayed graph rises over the seek bar, and taps on the bottom bar buzz so you feel them.

### New

- Playlist pages like YouTube's: a backdrop from the cover, sort, All / Videos / Shorts pills, Download all or Select videos, and a + on Watch later to add videos.
- Equalizer in the player's gear menu, applied live (#236).
- Tapping a comment in the watch page's comment preview opens the comments right at it, briefly highlighted.
- Double tap to skip shows where the video lands in a frosted time pill.
- Five new app icons by @m0in01: Red CRT, Chrome Play, Pixel Play, Starry Night and GTA VI (#193).

### Changed

- The You page's Library and Explore sit on a minimal glass card, and the corner light takes your accent colour. Customization > You page glow brings back the RGB light.
- Light mode gets its own light glass on pages, while the glass over the video stays dark.
- Alert dialogs are frosted glass like the sheets.
- Every menu row has an icon.

### Fixed

- A headset's button resumes a video it paused (#235).
- The mini player keeps showing after Shorts (#233).
- Restart in Settings works again.
- Sudo brew coffee in About and the README have a new QR and UPI ID (`yashwynth@slc`). Sorry if you tried to donate while the old one wasn't working.

### Thanks

Thanks to everyone who reports issues, and in this release to @m0in01, @sirpaarth-beep, @dhanunjay333i-cyber, @mhommad222 and @orbit21.

## 3.3.7 Melmo

> **Connected**<br>
> 📅 2026-11-12 · closes #173, #200, #223, #224, #225, #226, #227, #229 and #230

### ✨ Highlights

- **Community posts:** channels have a Posts tab. Like posts, comment and reply right in MeeTube, with counts that update at once and a little pop on every like.
- **Live chat on live videos:** chat along with the stream from a real comment box, pick which Google account to chat as (with avatars), and see the full Live chat feed with its history the moment it opens.
- **AutoEq headphone correction:** search about 9,000 headphone profiles from AutoEq in the Equalizer and MeeTube tunes the sound for your exact pair, exact on every phone and kept for offline use.
- **Update notifications:** a new MeeTube version now shows up in your notification shade, even with the app closed. Settings > About > Notify about updates turns it off.

### New

- Web accounts for chatting and posts sit in their own tab in the Accounts sheet, separate from your main account, and Sign in is now Add account.
- Accent colour palette: pick the app's accent from eight gradient palettes in Customization, and the Player and Shorts progress line colours with it.
- Double tap to skip shows a springy glass seek pill that counts up +10, +20, +30 as you tap. Customization > Seek pill brings back the classic ripple.
- Settings > Storage shows how full your phone is, what MeeTube takes, and clears the cache in one tap while your downloads stay.
- Mix and playlist cards are a stack, with two cards peeking above the thumbnail.
- Time pills show radio waves before a Mix and a music note before a music video. Customization > Icons on time pills turns them off.
- Ambient mode in landscape: the bands beside a video that doesn't fill the screen glow with its colours.
- Tablets in landscape keep a horizontal watch page, with Up next in its own column (#230).
- The progress line under the video can be turned off in Customization (#200).
- A long press hides a Short's buttons for every Short after it, until another long press brings them back (#173).
- The Minimal mini player is the video itself, with the title and buttons over a soft shade (#226).
- A new UPI ID for coffee in About > Sudo brew coffee, with a QR to scan.

### Changed

- SponsorBlock: every kind of part picks Skip, Ask, Show or Off right on its row.
- Chapter titles show as a frosted pill above the seek bar instead of a pop-up that stuck over the video (#223).
- The Storage page is all glass: a frosted Clear cache button and a glowing storage line in your accent.
- Back from a channel's Posts returns to the channel.
- More of MeeTube speaks Russian, thanks to @MAKAKAIglitch (#221).

### Fixed

- Shorts from Home's shelf keep going past the first 6 or 7 (#227).
- Videos no longer stutter after visiting the You page (#229).
- Search suggestions sit above the filter chips again (#224).
- The mini player bar keeps the video's real shape (#225).
- Fullscreen comments open again in landscape, and their glass rim no longer lingers on a drag.
- Shorts from the You page's History row always open in the Shorts player.
- The You page's History row no longer blinks out on a revisit.

### Thanks

Thanks to everyone who reports issues, and in this release to @Ishaanj2007, @dhanunjay333i-cyber, @KrishnakantShedge, @nouse8192-tech and @MAKAKAIglitch.

## 3.3.5 Sentinel

> **Immersive**<br>
> 📅 2026-11-08 · closes #188, #195, #196, #199, #201, #202, #203, #205, #213, #214, #215, #216, #217, #218 and #219

### ✨ Highlights

- **Home autoplay:** the card in the middle of your feed plays muted right in its thumbnail, with mute and captions buttons and a countdown. Pick Wi-Fi only, always or off in Settings > Playback.
- **Smart downloads:** a new Settings > Downloads page. Pick the folder and a default quality so one tap downloads, or turn on auto download for new uploads from the channels and playlists you choose (#202, #203).
- **Dolby Atmos:** when a video has a Dolby Atmos or 5.1 track and your phone can decode it, MeeTube plays it instead of stereo. It's on by default, and you can turn it off in Settings > Audio.
- **Your own seek bar thumb:** swap the player's dot for any picture from your phone in Customization > Seek bar thumb. GIFs and animated WebP move too.
- **iOS-style segment pills:** Home chips, search filters and Up next sit in a glass segment bar with a springy pill you can drag. Customization > Chips style brings the old pills back.

### New

- Drag the seek bar and a filmstrip rolls under your finger, with a big time and the chapter title (#195).
- A More videos button in the fullscreen controls (#196).
- Mini player styles in Customization: Default (pinch to resize), Minimal, Minimal 2 or Disabled. It also stays wherever you let it go (#188).
- Home can be removed from the bottom bar (#213).
- Settings > Install on TV puts MeeTube TV on your Android TV, Google TV or Fire TV straight from your phone, with a step-by-step guide.
- A Haptics toggle in Settings > App turns off every vibration.
- Customization toggles to hide the Cast button and Home's topic chips.
- Sudo brew coffee in About now asks where you are: UPI for India, Buy Me a Coffee everywhere else.
- MeeTube speaks Russian, thanks to @MAKAKAIglitch (#194).

### Changed

- The liquid glass switch has a jelly lens you can drag. Weaker phones get a plain switch.
- The Equalizer and Player volume use glass spring sliders, and volume changes live as you drag.
- Panels have a drag handle at the top, and Chapters and Description open under the video like Comments (#217, #218, #219).
- Home chips, shelves and channel cards line up on the same margins as the video cards (#199).
- Channels show as glass cards, and the You page menu fits two to a row.
- The locked player shows only a padlock, with no dot and no gap at the bottom (#201).
- The Shorts header is glass lettering, and the Shorts play/pause icon is quicker (#216).
- Settings' frosted top bar blends up through the status bar.
- The watch action pills fade out at the edges instead of being cut off.

### Fixed

- No more grey block behind landscape comments; the video slides aside smoothly (#214).
- The History row on the You page no longer jumps one video in (#215).
- No gap under a one-line title in portrait fullscreen (#205).
- No more still play icon or black frame before the launch animation.

### Thanks

Thanks to everyone who reports issues, and in this release to @KrishnakantShedge, @Ishaanj2007, @dhanunjay333i-cyber, @Evergreenpro, @Reird, @upt8543-eng and @MAKAKAIglitch.

## 3.3.1 Pluto

> **Tuned**<br>
> 📅 2026-11-04 · closes #69, #87, #151, #157, #167, #171, #172, #175, #177, #179, #181, #190 and #191

### 🎚️ YouTube Equalizer

- An Equalizer for everything you watch: your phone's presets or your own bands, applied live, in Settings > Audio quality (#177).
- Stable volume is off by default, so you hear YouTube's original audio instead of its compressed track.
- Player volume goes up to 200%.

### 📺 Try MeeTube TV

MeeTube's glass design is on Android TV and Google TV, in beta. Get [MeeTube TV 0.0.1 Beta](https://github.com/yashoncode/meetube/releases/tag/tv-v0.0.1-beta), try it on your TV and tell me what you think: [open an issue](https://github.com/yashoncode/meetube/issues/new/choose) and pick MeeTube TV, or say it in [Discussions](https://github.com/yashoncode/meetube/discussions).

### New

- Pause and resume downloads from their menu or notification, and a download cut off by closing the app comes back paused instead of failed (#191).
- Tap a timestamp in a video's description to jump there (#175).
- Hold a channel in the Subscriptions strip to open its menu, and tap it again to go back to All (#87).
- Player button style in Customization: See-through, Frosted, or Minimal with bare icons like YouTube.
- App name in the top bar in Customization: turn it off and only the icon shows.
- MeeTube speaks Arabic on every phone screen and setting, with fixes to the existing Arabic text (#69).

### Changed

- The top bar slides away as you scroll down and comes back when you scroll up; Always show the top bar keeps it in place (#181).
- Description, Lyrics and Transcript open under the video like Comments, so the seek bar stays in sight.
- A tap on the locked player shows the seek bar, the time and the chapter (#157).
- When a video ends, Pause is now Stop, and the video waits at its end with Replay (#167).
- On the You page your profile picture sits in a frosted glass disc, and every Library and Explore icon gets a frosted bubble.
- Every row of a download's menu has an icon, and the Pin to You rows get a pin.

### Fixed

- Shorts keep playing after a swipe (#172).
- A minimized video keeps playing when you tap Home from Search or a channel (#171).
- The Home tab opens Home after History, instead of refreshing History (#179).
- Each chapter pop-up shows once, not again after a seek or when the controls hide (#151).
- GIFs in comments show up instead of a blank comment (#190).
- Shorts from History open in the Shorts player.
- Menu icons no longer vanish in the light theme.
- The tab bar's Search bubble and lens stay inside the bar.
- A crash after closing a Short is gone.

### Thanks

Thanks to everyone who reports issues, and in this release to @Hammoudi99, @KrishnakantShedge, @Ishaanj2007, @dhanunjay333i-cyber, @Evergreenpro, @alibinarshad, @mygtvact and @sakuraDev31.

## 3.3.0 Glitch

> **Polished**<br>
> 📅 2026-11-03 · closes #158, #159, #160, #162, #164, #165, #166, #168 and #170

### New

- Try [MeeTube TV](https://github.com/yashoncode/meetube/releases/tag/tv-v0.0.1-beta) on your TV now, in beta on Releases.
- Held sideways, the description opens as a card beside the video, which keeps playing.
- Tap the video title in fullscreen to open the description (#164).
- Tap the channel name in the description to open the channel, so the Videos button is gone (#160).
- Search glow and Typing glow switches for the Siri colours in Search.
- A Grey tab glow.

### Changed

- One swipe shrinks Subscribe and scrolls the compact actions to the end, with a tick at either end (#158).
- The fullscreen title sits centred beside the top buttons (#165).
- Closing comments in upright fullscreen goes back to upright fullscreen (#166).
- Every message pill is the same dark frosted glass, and over the player it frosts the video live.
- On the You page the rows fade away under the top pills as you scroll.
- The tab glow fades in and out more smoothly.
- Customization shows its choices and switches as pictures.
- Shorts tiles have rounded corners everywhere.
- Light theme: a red tab glow and launch animation, brighter Accounts and Settings buttons, a see-through Comments card, and Ambient mode off unless you turn it on.
- The cast screens name MeeTube TV / SmartTube TV wherever they said SmartTube.
- No shadow under the Up next chips.

### Fixed

- Swiping the volume no longer makes the video stutter (#170).
- The channel picture and the Subscribe label show in the description again (#159).
- No octagon inside the fullscreen button in the light theme (#162).
- The Home chips' shadows are no longer cut off in the light theme (#161).
- The History row on the You page opens at its start, without flashing your last scroll first (#168).

### Thanks

Thanks to everyone who reports issues, and in this release to @KrishnakantShedge and @Batmancpu.

## 3.2.7 HotLight

> **Lighter**<br>
> 📅 2026-11-02 · closes #64, #144 and #148

### New

- Swipe brightness all the way down to switch to Auto brightness (#64).
- Every list bounces and stretches when you scroll past its ends.
- The About card tilts as you move your phone.
- A terminal style thank you note above the coffee button.

### Changed

- The app is half the size: 32 MB instead of 62 MB on most phones.
- No scroll bars anywhere.
- The Settings back button presses in like a real button.
- The tab bar lens pops out less and switches faster.
- About gets a Creator heading and a shorter issue reporters line.

### Fixed

- The app opens on Home again after you swipe it away from recents (#148).
- No black bar behind see-through keyboards in Search, Settings search and comments (#144).
- A landscape video after a vertical one in upright fullscreen now turns to landscape.
- Picture-in-picture no longer flashes the full controls when it opens.
- Emoji only comments no longer offer Translate.
- Dropped old TV permissions that made Play Protect flag the app.

### Thanks

Thanks to everyone who reports issues, and in this release to @KrishnakantShedge, @Batmancpu and @alibinarshad.

## 3.2.5 Plazma

> **Smoother**<br>
> 📅 2026-11-01 · closes #138, #139, #140 and #141

### New

- **Shorts shelf on Home.** Each Shorts row is one card you swipe sideways. Turn it off in Settings > Customize layout (#43).
- **Long press Easter egg.** Long press the brand pill to check it out.
- **Search bubble.** Scrolling down shrinks the bottom bar into a Search button in a corner, scrolling up brings it back.
- **Translate comments** right under the comment (#139).
- **A new About page.** A glass card with Star, Share and Send log buttons, plus Issue reporters and Contributors pages.
- **Exact counts.** Video details shows the full view and like numbers.

### Changed

- **Shorts swipe like Reels.** The next short is ready under your finger, even with Loop shorts off.
- **More glass.** A frosted Settings top bar, icons in glass beads, frosted duration pills on thumbnails and a lit rim on pop-ups.

### Fixed

- **Subtitles stay on screen** when a fullscreen video is zoomed, and two lines at once no longer overlap (#138).
- **Home chips line up** with the pills and cards (#140).
- **The comment like press** is no longer cut on the left (#141).
- **Home no longer jumps into picture-in-picture** when you open Settings on Android 8 to 11 (#143).

### Thanks

Thanks to everyone who reports issues, and in this release to @sushi1579, @AshUchiha3, @KrishnakantShedge and @karthick4568. Keep them coming.

### Coming soon

**MeeTube for TV.**

## 3.2.3 Mirage

> **Pick your spinner and icon, Shorts autoscroll, a mini player that rides the bottom bar**<br>
> 📅 2026-10-31 · closes #85, #114, #117, #118, #120, #121, #122, #123, #124, #125, #127, #129, #130, #132 and #134

### ✨ New

- **Pick your loading spinner.** Customization has Neon ring, Frosted glass, Cookie, Frosted cookie and a liquid glass set: Liquid ring, Glass orb, Liquid blob and Glass orbit. One choice changes every spinner in the app, the pull to refresh circle included (#114).
- **More app icons.** Eight icons named by look: Classic, Black Heart, Fantasy, Glass Heart, OG Glass, OG Play, OG Neon and Fiery Blaze. Each is its shape alone on a clear background, on the home screen, in Settings and on the splash.
- **A launch animation.** A play symbol grows in and melts into frosted glass over Home, the same for every icon, in under a second.
- **Shorts autoscroll.** When a short ends, play it again or move on to the next one, which slides up as a swipe does. Auto-scroll is also in a short's menu (#134).
- **Save, share and import your settings.** Settings > Backup saves them to a file or shares them with a friend. Only settings travel, never accounts, linked devices, history, caches or passwords, and an import keeps this phone's passwords.
- **Hide the red watched line** on thumbnails with a switch in Customization (#132).
- **A hint on a held tab.** Holding a bottom bar tab shows a glass pill: "Tabs customization" with tab names on, or the tab's name and "Change" with them off. A tap opens Settings > Tabs (#130).
- **Tap the open tab to refresh.** With its feed at the top, tapping the tab you are on refreshes it like a pull. A scrolled feed still glides to the top.
- **Upload date on the watch page.** Channel, subscribers, views and when it went up ("3 days ago"), on one line.
- **More qualities on more phones.** The quality sheet also lists the rungs your phone's decoder reports beyond it, such as 2160p60, as YouTube does. If one really can't play, the video drops back to 1080p (#85).

### 🛠️ Changed

- **The player lock is glass.** The lock button and the locked state sit on the player's glass like its other buttons. Locked reads "Locked · tap to unlock" with a shut padlock, and both drag anywhere over the video and keep their spot (#124, #127).
- **The mini player rides the bottom bar.** On Home, Search and channel pages a card at a bottom corner slides down with a small bounce when a scroll hides the bar, and back up with it. Swiping the player down lands straight on it (#125).
- **The refresh sound is off by default.** Switch it on in Customization (#120).
- **A bouncier bottom bar drag.** A drag starts anywhere on the bar, the bar bounces out under your finger, the tab under the lens pops and the tab glow follows the finger.
- **A linear brightness swipe** in fullscreen: half way up is half the brightness (#129).
- **Controls after a play from outside.** A play from headphones, the lock screen or the notification brings up the controls (#121).
- **A quality pick is for one video.** A pick in the player's quality sheet holds for that video; the next one opens at your Settings quality, and Auto in the sheet goes back to it.
- **A softer Shorts edge fade.** Half as wide, eased at both ends, and on a zoomed or moved short it stays on the video's real edges (#117).
- **The pull to refresh disc is see-through glass.**
- **The diagnostic log** lists the last three reasons the app closed.

### 🐛 Fixed

- **The bottom bar in landscape** sits centred at a comfortable width instead of across the whole screen, on Search and channel pages too (#118).
- **Picking 1080p no longer plays 240p** on videos played from HLS (#58).
- **Hide Up next hides the whole section,** with no label, placeholder rows or chips (#122).
- **The Up next card in fullscreen** sizes to its content instead of spanning the screen (#123).
- **Home after a minimize** no longer stays in two columns in portrait after the phone was turned, and the Shorts tab keeps its two columns when it turns.
- **The first launch after an install** shows no splash icon instead of the wrong one.

### ✅ Issues resolved

| Issue | Asked for | In 3.2.3 |
| :-- | :-- | :-- |
| [#85](https://github.com/yashoncode/meetube/issues/85) | 4K, 2K and 60 fps qualities on every phone | Rungs the decoder doubts are listed too |
| [#114](https://github.com/yashoncode/meetube/issues/114) | The frosted loading spinner back | Spinner picker with Frosted glass and more |
| [#117](https://github.com/yashoncode/meetube/issues/117) | A smoother Shorts edge fade | Half as wide, eased, follows a zoomed short |
| [#118](https://github.com/yashoncode/meetube/issues/118) | A nav bar that fits landscape | Centred, at most 480dp wide |
| [#120](https://github.com/yashoncode/meetube/issues/120) | Turn off the refresh sound | Off by default, a switch in Customization |
| [#121](https://github.com/yashoncode/meetube/issues/121) | Controls after a play from outside | Headphones, lock screen and notification show them |
| [#122](https://github.com/yashoncode/meetube/issues/122) | Hide Up next hides it all | No label, placeholder rows or chips |
| [#123](https://github.com/yashoncode/meetube/issues/123) | A smaller Up next card in fullscreen | The card sizes to its content |
| [#124](https://github.com/yashoncode/meetube/issues/124) | A glass lock button that moves | Lock on the player glass, drag it anywhere |
| [#125](https://github.com/yashoncode/meetube/issues/125) | Mini player down with the bottom bar | It rides the bar on Home, Search and channels |
| [#127](https://github.com/yashoncode/meetube/issues/127) | A clear locked state | "Locked · tap to unlock" pill with a shut padlock |
| [#129](https://github.com/yashoncode/meetube/issues/129) | A linear brightness swipe | Half way up is half the brightness |
| [#130](https://github.com/yashoncode/meetube/issues/130) | A new bottom bar long press | A glass hint that opens Tabs customization |
| [#132](https://github.com/yashoncode/meetube/issues/132) | Hide the red watched line | A switch in Customization |
| [#134](https://github.com/yashoncode/meetube/issues/134) | Autoscroll in Shorts | Replay or move to the next short when one ends |

## 3.2.1 Sublime

> **Shorts that open instantly, a SponsorBlock skip pill, transcripts for songs without lyrics**<br>
> 📅 2026-10-28 · closes #84, #103, #104, #105, #106, #107, #108 and #109

### ✨ New

- **SponsorBlock skip pill.** A sponsor or other skippable segment shows a small Skip pill on the player while the video plays on; tap it to jump past the segment.
- **Transcript when there are no lyrics.** A song without lyrics opens its transcript in the Lyrics panel, which says lyrics aren't available. Transcript is also the last choice in the lyrics provider list.
- **Watch Shorts in the normal player.** A short's More menu has Watch in normal player, which opens it in the regular player with Up next (#108).
- **New to you and Continue watching.** Up next chips that split the related videos into ones you haven't seen and ones you started (#104, #105).
- **Picture-in-picture when you leave, your choice.** Settings > Playback > Picture-in-picture: off, leaving the app with a video playing goes on as audio. The player menu still opens picture-in-picture (#103).
- **Shorts in History.** History lists the Shorts you watched, and a tapped one plays in the Shorts player with your other watched Shorts.
- **A rest nudge.** After half an hour of swiping Shorts, MeeTube suggests a break.
- **Built in public.** About and the README link to the workflow that builds every release.

### 🛠️ Changed

- **Shorts open instantly** from the tab, like Search. The bottom bar slides away and stays away while Shorts is up (#107).
- **Slide down to close Shorts.** Back slides the player down off the screen, with the tab you came from already beneath it.
- **One neon ring loader.** A cyan to magenta glow ring is the loader on every page, sheet and button.
- **Up next chips are glass pills** like Search's.
- **A tidier watch page.** The page moves with a tall video on the same frame, and the action pills line up right after Subscribe (#106).
- **One place for video quality.** The Video format row is gone from Settings; every format is in the player's quality sheet.

### 🐛 Fixed

- **Skipping no longer stops playback** with SABR streaming, and a SABR failure picks up the video over DASH where it was instead of stopping (#109).
- **Tapping a channel in Channels** no longer swaps the list for its uploads, which then stayed after Back (#84).
- **No empty strip above the Lyrics and Transcript panels.** The panels' handle sits right under the video again.

## 3.2.0 Rebirth

> **MeTube is now MeeTube: downloads up to 4K, GlowFlow everywhere**<br>
> 📅 2026-10-28 · closes #47, #71, #74, #75, #76, #77, #90, #91, #94, #98, #99 and #101

### 📣 MeTube is now MeeTube

- **A new name, a new app.** MeTube is reborn as MeeTube, with a new app id (`io.yash.meetube`). Android sees it as a different app, so **MeeTube installs as a separate app next to MeTube** instead of updating it.
- **Install MeeTube, then uninstall the old MeTube.** Sign in again in MeeTube and set your settings once; the old app keeps its own and gets no more updates.
- **Your old downloads stay where they were,** in Movies/MeTube and Music/MeTube. New ones go to Movies/MeeTube and Music/MeeTube.
- **A new default icon.** The red heart on a white tile is MeeTube's icon now. The painted heart is still there as Fantasy, and Classic too, in Settings > Customization > App icon.

### ✨ New

- **Downloads up to 4K.** Save videos in 1440p and 4K as well as up to 1080p. YouTube serves those only as VP9, so MeeTube fetches the best VP9 video and Opus audio and joins them into one WebM file on your phone. Up to 1080p stays MP4 (#94).
- **Save downloads where you like.** Pick any folder on your phone in Settings, or long press Download on the watch page. If the folder stops being writable, downloads go to the default one again (#75).
- **Open in folder.** A download's menu opens its folder in your file manager.
- **GlowFlow, a glow that moves with you.** Light now flows through the whole app:
  - **Tab glow.** A soft glow sits behind the lit tab and slides to the next one as you switch, changing colour on the way. Pick White, Tab colors (each tab its own colour) or Accent (MeeTube red) in Settings > Customization > Tab glow, or turn it off (#47).
  - **Progress glow.** The played part of every progress line glows at its head and ends round: the player's seek bar, the cards' watched line, the mini player and Shorts. Settings > Customization > Progress glow turns it off.
  - **Counts that run up.** A short's counts run up from zero the first time it shows.
- **Drag along the bottom bar.** Slide your finger along the bar: the glass lens follows it with a tick per tab, and the tab you let go on opens (#90).
- **Swipe a video out of History.** Swipe a card sideways to remove it from your watch history (#71).
- **Player lock.** In fullscreen, a lock button shuts out every swipe, tap, pinch and double tap; tap to show the unlock button. Hide it in Customization > Player buttons (#98).
- **Choose your player buttons.** Settings shows or hides each of the player's buttons (#76).
- **A transcript that follows the video.** For a video with captions, Transcript in the player menu opens a searchable sheet that follows playback; tap a line to jump there.
- **A richer description.** The description sheet ends with the channel, its transcript and the video's details.
- **Two watch page looks.** Compact puts the actions beside Subscribe and shows top comments one by one; Classic keeps the old layout. In Compact, Subscribe turns into the app's mark while you swipe the actions.
- **Up next chips.** All and From the channel chips over the Up next list (#74).

### 🛠️ Changed

- **A glass loading spinner.** A thin white arc on a frosted glass disc replaces the red spinner (#77).
- **Pull to refresh pops.** A light haptic and a soft two-note pop, silent when your phone is on silent or vibrate.
- **Up next follows your video layout,** Cards or List, and a list refreshes with row placeholders instead of cards (#91).
- **Menus with icons.** Every action in a video's or channel's menu has its icon, with a rounded highlight like YouTube's.
- **A smaller time pill** on the player.
- **A smoother Subscribe morph** when you swipe the watch page actions.
- **Shorts keep coming.** The Shorts tab fetches its next page well before you reach the end.

### 🐛 Fixed

- **The mini player grows from where you dragged it,** and square or vertical videos no longer stretch on the way (#99).
- **Pausing from outside shows the controls.** Unplugging earphones, a headset button or another app's sound now brings the controls up so you can see it is paused (#101).
- **A paused video comes back playable** after Android closes the app in the background.
- **A double tap jump moves the progress bar at once.**
- **The subscriber count is never cut short** on the Compact watch page.
- **The mini player lands above the channel page's bar** instead of jumping up from under it.
- **The You tab no longer flashes** the last page while it fades in.

### ✅ Issues resolved

| Issue | Asked for | In 3.2.0 |
| :-- | :-- | :-- |
| [#47](https://github.com/yashoncode/meetube/issues/47) | A colour bloom on the selected tab | Tab glow: White, Tab colors or Accent |
| [#71](https://github.com/yashoncode/meetube/issues/71) | Side swipe on the History page | Swipe a card to remove it |
| [#74](https://github.com/yashoncode/meetube/issues/74) | Topic chips while watching | All and From the channel chips on Up next |
| [#75](https://github.com/yashoncode/meetube/issues/75) | Long press Download to save to phone storage | Long press picks the download folder |
| [#76](https://github.com/yashoncode/meetube/issues/76) | Customizable player controls | Show or hide each player button |
| [#77](https://github.com/yashoncode/meetube/issues/77) | A glass loading spinner | A white arc on frosted glass |
| [#90](https://github.com/yashoncode/meetube/issues/90) | A better navigation bar | Drag along the bar to switch tabs |
| [#91](https://github.com/yashoncode/meetube/issues/91) | Refresh shows cards in List layout | Row placeholders for lists |
| [#94](https://github.com/yashoncode/meetube/issues/94) | 4K downloads | 1440p and 4K downloads |
| [#98](https://github.com/yashoncode/meetube/issues/98) | A player lock | Lock button in fullscreen |
| [#99](https://github.com/yashoncode/meetube/issues/99) | Mini player grow animation | Grows from the card, no stretch |
| [#101](https://github.com/yashoncode/meetube/issues/101) | Show controls after an outside pause | Controls come up on any pause |

## 3.1.8 Lora

> **Live rings, a playful Customization page, zoom anywhere**<br>
> 📅 2026-10-27 · closes #46, #55, #73, #78, #79, #80, #81, #82, #83 and #86

### ✨ New

- **See who is live at a glance.** A channel streaming right now gets a glowing red ring around its picture: on video cards, in your Subscriptions strip, on the watch page and on the channel page, where a LIVE badge sits under it and a tap on the picture opens the stream (#73).
- **Home chips made for you.** Right after All, Home now shows chips for the channels you watch most, picked from your watch history. Tap one for that channel's latest videos; Back takes you to All again (#79).
- **Videos as a list.** Settings > Customization > Video layout shows videos as compact rows with a small thumbnail beside the title, so more fit on screen. It works on Home, Subscriptions, channels, playlists and search. Shorts stay as tiles (#82).
- **Pinch to zoom, anywhere.** Zoom into the video up to 5x on the small player, in Shorts and in fullscreen, and move around with two fingers. Each new video starts whole again (#55).
- **Comments like on YouTube.** Tap a comment to open its replies, double tap it to like it (#78).
- **A liquid glass lens on the bottom bar.** Pick a tab and a glass lens glides over to it while the bar wiggles. Turn it off under Settings > Customization > Tab switch animation (#46).
- **Frosted player buttons are back, as a setting.** Turn on Settings > Customization > Frosted player buttons and the buttons over a video and a short blur the picture under them again. It is off by default because it costs battery on slower phones (#80).
- **High performance mode.** Settings > General > High performance mode keeps the app at your screen's top refresh rate, 120 Hz on most newer phones, for the smoothest scrolling. Off by default.
- **All subscriptions in one list.** Hold All on the Subscriptions strip to see every channel you follow, A to Z.
- **Reset the bar.** Settings > Customization > Tabs has a button that puts the bar back to Home, Shorts, Search, Subs and You.

### 🛠️ Changed

- **A playful Customization page.** Theme, app icon, Home layout, video layout, thumbnails and playlists are now picture tiles you tap, and Interface size is a slider with a live preview. Everything sits in four groups: Look, Layout, Glass and motion, Tabs and menus.
- **Frosted glass switches.** Every switch in the app is a simple frosted glass toggle now.
- **Tabs arrive out of frosted glass.** Switching tabs, the new page clears in from a soft blur.
- **Shorts open smoother.** The Shorts player rises in from the bottom once the bar has settled, and going back is smoother too.
- **Hold a short to see it clean.** The buttons fade away while you hold, and stay away after you let go until you touch the screen again. For 2x speed, hold the top right corner instead.
- **The bottom bar stays on channel pages,** with the tab you came from still lit.
- **Smaller buttons on the small player,** so they cover less of the video. Fullscreen keeps the big ones.

### 🐛 Fixed

- **Streams that just ended play again.** A live stream that finished in the last few hours only showed Retry. It now plays from the start (#83).
- **Back on a filtered Subscriptions feed** goes to All your channels first, not to Home (#86).
- **Bottom bar names line up.** "Subscriptions" wrapped onto two lines; the bar now says "Subs" (#81).
- **Home no longer opens a menu on a long press** of its tab.
- **Minimizing the player no longer jumps** back and forth on some phones.

### ✅ Issues resolved

| Issue | Asked for | In 3.1.8 |
| :-- | :-- | :-- |
| [#46](https://github.com/yashoncode/meetube/issues/46) | A liquid glass bottom bar with effect settings | A glass lens glides between tabs, with its own switch |
| [#55](https://github.com/yashoncode/meetube/issues/55) | Zoom in the video player | Pinch to zoom up to 5x, everywhere |
| [#73](https://github.com/yashoncode/meetube/issues/73) | A red ring on live channels | A glowing ring wherever the channel shows |
| [#78](https://github.com/yashoncode/meetube/issues/78) | YouTube style comment taps | Tap for replies, double tap to like |
| [#79](https://github.com/yashoncode/meetube/issues/79) | Personal Home chips | Chips for the channels you watch most |
| [#80](https://github.com/yashoncode/meetube/issues/80) | Glass player buttons are gone | Frosted player buttons setting |
| [#81](https://github.com/yashoncode/meetube/issues/81) | Bottom bar names out of line | "Subs" fits on one line |
| [#82](https://github.com/yashoncode/meetube/issues/82) | Videos as a list | Video layout: Cards or List |
| [#83](https://github.com/yashoncode/meetube/issues/83) | Recent live streams only show Retry | They play from the start |
| [#86](https://github.com/yashoncode/meetube/issues/86) | Back from a channel goes Home | Back goes to All first |

## 3.1.7 Clozone

> **Your bars your way, live chat beside the video, share from the second**<br>
> 📅 2026-10-26 · closes #31, #32, #33, #37, #42, #54, #63, #65, #66, #67 and #68

### 💌 Love MeeTube? Your friends might too

- **Know someone still sitting through ads?** If MeeTube spared you even one unskippable ad this week, there is probably a friend, a cousin or a mum out there still watching all of them like it is 2015. Send them [the download link](https://github.com/yashoncode/meetube/releases/latest). Or don't, and keep the ad free life to yourself. We will just be here, refreshing the download count every five minutes, totally fine about it.

### ✨ New

- **Arrange your bars by dragging.** Settings > Customization > Tabs now shows your bars as a stack of tiles with a small preview above them. Hold a tile, or grab its grip, and slide it: Search and your two tabs move between Home and You, and the preview follows along. Drag Search up and it moves to the top bar next to Cast, like on YouTube. Tap a tab to change what it shows (#31).
- **Live chat beside the video.** Upright, the chat sits under the video instead of covering it. Sideways, a chat button on the fullscreen pill opens it as a card on the right, and the video slides over to make room. Comments in landscape open in the same card (#32).
- **Share from the second you are on.** A tap on Share sends the link as before. Hold it to send the link from where you are now, so your friend lands right on the good part (#68).
- **Tap the time to see what is left.** The time on the player flips to the time remaining and back, and MeeTube remembers your pick (#67).
- **Hold a video in Up next for its menu.** The same menu as on Home: queue, save to a playlist, share and the rest (#66).
- **Swipe a video out of your own playlists.** Watch later too. Changed your mind? Undo puts it back (#65).
- **Mute, search and download on Shorts,** small at the top right like YouTube's. Mute stays on from short to short until you tap it again.

### 🛠️ Changed

- **The bottom bar gets out of the way.** It hides while you scroll down and comes back when you scroll up, and Search results get the same floating bar (#37).
- **Shorts show your own picks first.** The Shorts tab opens on the Shorts from your account's Home, not just your subscriptions' (#42).
- **A short's description is one tap away.** Tap its title (#33).
- **Only tall Shorts fill the screen.** A square or wide short now shows whole, with the glow around it, instead of losing its sides.
- **The mini player goes where you put it.** Drag it anywhere and it springs to the nearest corner. Fling it sideways to close it.
- **The status bar glows with the video,** and Home blurs behind the player as you swipe it down to the mini player (Android 12 and newer).
- **HDR says so.** With HDR on, the Quality sheet labels HDR streams, like "2160p60 HDR" (#63).
- **Glass Accounts and Settings buttons** on the You page, with the colour light showing through.
- **Channel pictures on Shorts fade in** like the ones on Home, instead of popping in.
- **The Explore compass on Home is gone.** Music, Live, Gaming, News and Sports are still under Explore on the You page.

### 🐛 Fixed

- **Your History shows the Shorts you watched.** If you mostly watched Shorts lately, History looked empty.
- **A tab you put on the bar shows up.** Turning it off under You used to hide it from the bar too. Putting it on the bar now turns it back on (#54).
- **One decoder hiccup no longer lowers your quality for good.** When the phone could not start a video, MeeTube dropped to 1080p and kept it for every video after. Now only that one video falls back. Thanks to NewTube for this fix.
- **Swiping the player down from Search** no longer slips under the bottom bar and jumps.

### ✅ Issues resolved

| Issue | Asked for | In 3.1.7 |
| :-- | :-- | :-- |
| [#31](https://github.com/yashoncode/meetube/issues/31) | Search button in the top bar | Drag Search up into the top bar |
| [#32](https://github.com/yashoncode/meetube/issues/32) | Live chat is hard to see, and missing in landscape | Chat under the video, or a card beside it |
| [#33](https://github.com/yashoncode/meetube/issues/33) | A description for Shorts | Tap a short's title |
| [#37](https://github.com/yashoncode/meetube/issues/37) | A bottom bar that hides like YouTube's | It hides as you scroll down |
| [#42](https://github.com/yashoncode/meetube/issues/42) | Shorts don't match the YouTube app | Your account's Shorts come first |
| [#54](https://github.com/yashoncode/meetube/issues/54) | Subscriptions missing from the bar | A tab on the bar always shows |
| [#63](https://github.com/yashoncode/meetube/issues/63) | HDR next to the quality | HDR streams say HDR |
| [#65](https://github.com/yashoncode/meetube/issues/65) | Swipe to remove from a playlist | Swipe it out, with Undo |
| [#66](https://github.com/yashoncode/meetube/issues/66) | Hold a video for its menu | Hold any video in Up next |
| [#67](https://github.com/yashoncode/meetube/issues/67) | Show the time left | Tap the time to flip it |
| [#68](https://github.com/yashoncode/meetube/issues/68) | Share with a timestamp | Hold Share |

## 3.1.5 Orizon

> **A new You page, More videos in fullscreen, HDR video**<br>
> 📅 2026-10-25 · closes #24, #34, #35, #36, #38, #41, #45, #50, #56, #57 and #58

### 📣 A new name is coming

- **MeTube will get a new name soon.** The app, its features and your settings stay the same, and updates keep arriving as they do now. We want to pick the name with you: share your ideas and vote in [GitHub Discussions](https://github.com/yashoncode/meetube/discussions).

### ✨ New

- **A You page like YouTube's.** Your picture, name and email up top with Accounts and Settings buttons, your latest History in a row that scrolls sideways, then your Library and Explore. A soft light in the corner slowly drifts through the colours and fades into true black, so it stays easy on AMOLED screens.
- **Swipe up in fullscreen for More videos.** In landscape, a swipe up on the middle of the video raises a row of Up next videos while the video keeps playing. Pick one to play it, or swipe down, tap the video or press Back to put the row away. A small arrow at the bottom shows it is there (#24).
- **An Explore menu on Home.** A compass before the topic chips opens a side menu with Music, Live, Gaming, News and Sports, frosted over the page, with the same colour light and rounded corners.
- **HDR video.** Turn on HDR video in Settings > Player and HDR videos play in HDR on a screen that can show it. It is off by default (#35).

### 🛠️ Changed

- **The mini player opens on the first tap.** Its buttons fade away three seconds after it shows and come back when you touch it, and a tap on the video always opens it again (#34).
- **Under a tall video, swiping up shows the details.** The video box first shrinks to the usual size, as on YouTube, then the page scrolls. Pull down at the top to grow it back (#36).
- **Shorts stay Shorts in landscape.** Turn the phone or tablet sideways and you still swipe from short to short, see the whole short, and get comments beside it (#57).
- **A like moves the like count.** Liking a video or a short now adds one to the count, and taking the like back takes one off (#45).
- **Each channel tab keeps its place.** Switching between Videos, Shorts, Popular and the rest returns you to where you left each one (#50).
- **See-through glass everywhere.** The buttons over the video, the mini player's buttons, the Search filter chips and the Search filters dialog all use the same clear glass, so the video and results show through.

### 🐛 Fixed

- **The quality you pick is the quality you get.** On some videos, choosing 1080p played 240p while the button still said 1080p. Now the closest quality at or below your pick plays (#58).
- **Video titles no longer go missing.** A card that arrived with only a picture now fills in its title and channel by itself (#41).
- **Home no longer stays stuck on the loading placeholders** on some phones, such as the Galaxy A03 Core, after the videos have loaded (#56).
- **Leaving picture-in-picture no longer crashes,** and picture-in-picture no longer shows the whole app instead of the video (#38).

### ✅ Issues resolved

| Issue | Asked for | In 3.1.5 |
| :-- | :-- | :-- |
| [#24](https://github.com/yashoncode/meetube/issues/24) | A swipe-up More videos panel in fullscreen | Swipe up in landscape for a row of Up next videos |
| [#34](https://github.com/yashoncode/meetube/issues/34) | Fix the mini player | One tap opens it, its buttons fade away |
| [#35](https://github.com/yashoncode/meetube/issues/35) | HDR video | An HDR video switch in Settings > Player |
| [#36](https://github.com/yashoncode/meetube/issues/36) | Swipe up to see a tall video's details | The box shrinks first, then the page scrolls |
| [#38](https://github.com/yashoncode/meetube/issues/38) | Picture-in-picture shows the whole app | Only the video floats, and leaving it no longer crashes |
| [#41](https://github.com/yashoncode/meetube/issues/41) | Video titles sometimes missing | Missing titles fill themselves in |
| [#45](https://github.com/yashoncode/meetube/issues/45) | Liking Shorts doesn't update the like | The like count moves with your like |
| [#50](https://github.com/yashoncode/meetube/issues/50) | Channel tabs jump back to the top | Each tab keeps its scroll position |
| [#56](https://github.com/yashoncode/meetube/issues/56) | Home stuck on loading | The placeholders always make way for the videos |
| [#57](https://github.com/yashoncode/meetube/issues/57) | Shorts turn into a normal video in landscape | Shorts mode holds in any orientation |
| [#58](https://github.com/yashoncode/meetube/issues/58) | 1080p picked, 240p played | The nearest quality to your pick plays |

## 3.1.1 Spectre

> **MeeTube on Android TV, Shorts quality, tablet fixes**<br>
> 📅 2026-10-22 · closes #21, #25, #26, #27, #28, #29 and #30

### ✨ New

- **MeeTube on Android TV and TV boxes.** Install it on a TV, open it from the TV home screen and use it with just the remote. A white ring shows what you are on, everywhere. On Home, press Up from the first row for the topic chips and Back for the bottom bar. In the player, OK plays or pauses, Left and Right seek, Up and Down bring up the controls, and Back hides them before it leaves the video. In Shorts, Up and Down move between shorts. It is the same MeeTube you know from your phone, not SmartTube's TV look (#21).
- **Shorts have their own default quality.** Settings > Video quality has a Shorts row next to Wi-Fi and mobile data, so you can save data on Shorts and keep other videos sharp, or the other way round (#26).

### 🛠️ Changed

- **Shorts comments work like YouTube's.** They take two thirds of the screen with the whole short above them, and the short grows and shrinks with the comments as you drag them (#27).
- **The floating fullscreen button is see-through**, with a dark ring, so it no longer hides the comments under it (#29).
- **Tablets feel more at home.** A short shows whole when the zoom setting is Default, and its sides blend into the glow. The mini player is as big as picture-in-picture, sheets span an upright tablet's width, and the bottom bar is only as wide as its items (#25).

### 🐛 Fixed

- **The lyrics panel no longer follows you home.** Going Home with lyrics open used to carry the panel into the picture-in-picture window, and minimizing left it over the mini player. Lyrics and other open panels now close when the player shrinks (#30).
- **The video stays smooth under the settings sheet.** It stuttered for a moment when the sheet opened (#28).
- A long channel name on a short no longer splits the Subscribe button over two lines.

### ✅ Issues resolved

| Issue | Asked for | In 3.1.1 |
| :-- | :-- | :-- |
| [#21](https://github.com/yashoncode/meetube/issues/21) | Use MeeTube with a TV remote | A TV home screen entry and remote control on every screen |
| [#25](https://github.com/yashoncode/meetube/issues/25) | Shorts stretched on tablets | Tablets show the whole short when zoom is Default |
| [#26](https://github.com/yashoncode/meetube/issues/26) | A separate quality for Shorts | A Shorts row in Settings > Video quality |
| [#27](https://github.com/yashoncode/meetube/issues/27) | Shorts comments don't open fully | Comments take two thirds of the screen |
| [#28](https://github.com/yashoncode/meetube/issues/28) | Stutter when opening the video options | The video keeps playing smoothly |
| [#29](https://github.com/yashoncode/meetube/issues/29) | A lighter fullscreen button | A see-through button with a dark ring |
| [#30](https://github.com/yashoncode/meetube/issues/30) | Lyrics panel over the mini player | Open panels close when the player shrinks |

## 3.1.0 DoomsSlay

> **Actions in fullscreen, a video box that fits, quicker Shorts**<br>
> 📅 2026-10-22 · closes #9, #13, #17, #19 and #20

### ✨ New

- **Like, comment and share in fullscreen.** A small frosted pill under the seek bar, in landscape and vertical fullscreen, has like, dislike, comments, download and share, with the same state as the watch page. The arrow beside the fullscreen button hides it, and MeeTube remembers your choice (#9).
- **The video box takes the video's shape.** A square or vertical video no longer sits in a 16:9 box with black bars at its sides. The box follows the video, up to two thirds of the screen, so the title and buttons stay in sight (#13).
- **Live frosted glass over the player.** The settings sheet and the pickers opened over a video (download quality, repeat, zoom, save to playlist) blur the video as it keeps playing, instead of a frozen copy of it. Android 12 and newer (#17).
- **Shorts swipe faster.** The next short starts opening while the old one slides away, and stays preloaded while the current one loops. A swipe now plays the next short about a third sooner, with no red spinner over it and no jump from its picture to its video.
- **Comments beside the landscape video.** Comments opened in landscape fullscreen take a column on the right while the video plays on the left, like YouTube.
- **YouTube's vertical fullscreen.** Minimize and headphones at the top left, the title and channel under them, the seek bar and the actions just above the gesture bar.
- **Vertical videos go fullscreen upright.** The fullscreen button and the swipe up open a vertical video in vertical fullscreen, not turned to landscape with black bars.

### 🛠️ Changed

- **The mini player's buttons show on a tap**, like a picture-in-picture window. Tap the card for headphones, play/pause and close; tap the video while they show to open the player.
- **Vertical videos play in 1080p.** They were capped at 480p. Full quality also arrives sooner: the low quality start is replaced once the connection allows it, in about 5 s on Wi-Fi instead of about 10.
- **A quick double tap on play/pause plays or pauses**, like YouTube. With the controls hidden, the second tap used to hide them again.
- **Player sheets in landscape stay still and scroll.** Every row is in reach, and the last row on screen is cut in half and fades out, a hint that the list goes on.
- Shorts action buttons are a little smaller, and the second channel picture under them is gone.
- Romanian, Russian and Simplified Chinese cover more of the app, thanks to NewTube's translators on [Weblate](https://hosted.weblate.org/projects/newtube/).

### 🐛 Fixed

- **Home's grey placeholder stayed over the loaded videos** for seconds on slower phones, and could flash back when leaving Shorts. It now fades once (#20).
- **My videos looked broken with private or unlisted uploads.** YouTube never lists those to MeeTube's sign-in, only public ones; an empty My videos now says so instead of "Nothing to show here yet" (#19).
- **No pause and rewind at the one minute mark.** When YouTube refuses a session at 60 seconds, the buffered video keeps playing while MeeTube fetches a working link for the same stream.
- **Previous goes back even with SponsorBlock.** A second tap returns to the previous video even when SponsorBlock skipped an intro, and that video resumes where you left it.
- **The app opens on Android 7.0 again.**
- **Fullscreen on Android 11:** the gesture bar no longer stays on screen.
- Audio tracks are labelled better: original, dubbed and audio description tracks are told apart.
- Home no longer looks like it is loading again after you leave the fullscreen player.
- The app icon you picked shows on every launch screen and in recent apps, also after Android restarted MeeTube in the background.
- Videos open a little lighter: the remote control service is built only when it is used.

### ✅ Issues resolved

| Issue | Asked for | In 3.1.0 |
| :-- | :-- | :-- |
| [#9](https://github.com/yashoncode/meetube/issues/9) | Like, comment and share buttons in the player | A frosted action pill under the fullscreen seek bar |
| [#13](https://github.com/yashoncode/meetube/issues/13) | Fit the video frame to the video | The video box takes the video's own shape |
| [#17](https://github.com/yashoncode/meetube/issues/17) | Frosted glass on the player's settings pop-up | Live frosted glass on every sheet over the player |
| [#19](https://github.com/yashoncode/meetube/issues/19) | My videos doesn't show my uploads | My videos explains why private and unlisted uploads are missing |
| [#20](https://github.com/yashoncode/meetube/issues/20) | Placeholder stuck over Home on open | The placeholder fades once the videos load |

## 3.0.5

> **MeeTube in Traditional Chinese, Shorts on channels, search chips**<br>
> 📅 2026-10-21

### ✨ New

- **MeeTube in Traditional Chinese (繁體中文).** Every phone screen is translated for Taiwan, thanks to [@Capricornus007](https://github.com/Capricornus007) (#14). Channel pages now also show their stats in your language's own script.
- **A Shorts tab on channel pages.** Like YouTube's: tall tiles three to a row with the view count on each. Tap one to open the Shorts player and swipe through the channel's Shorts. Channels that only post Shorts no longer show an empty page.
- **Subscribe on the channel page.** Signed in, the channel header has a Subscribe button with the same splash as the watch page, and Undo.
- **Search chips.** All, Videos, Shorts, Live and Recently uploaded sit under the search bar, like YouTube's. One tap filters the results.
- **A frosted glass bar on channel pages.** The top bar and tabs frost the page scrolling under them.

### 🐛 Fixed

- Tapping the channel name or picture on a Short opened nothing, and a double tap there liked the video. Both now open the channel (#12).
- Tapping a channel picture on Home opened the channel after about a second; the page now opens at once and fills in.
- A channel opened from a youtube.com/@handle link now shows its header, Subscribe button and Shorts view counts.
- On a channel whose latest video is a collab, the header could show the other channel.

## 3.0.1

> **YouTube's search filters, Shorts in search, a real channel page**<br>
> 📅 2026-10-19

### ✨ New

- **YouTube's search filters.** The filter button opens the same "Search filters" YouTube has: Type, Duration, Upload date and Prioritize, plus Features chips: Live, 4K, HD, Subtitles/CC, Creative Commons, 360°, VR180, 3D, HDR, Location and Purchased. Any combination works now; before, many combinations quietly searched without a filter (#11).
- **Shorts in search.** Search results show Shorts the way YouTube does: a block of tall cards, two to a row. Tap one to open the Shorts player and swipe through the search's Shorts. Type › Shorts shows only Shorts (#11).
- **A channel page with a header.** The channel's banner, picture, name, @handle, subscribers and video count and its description (tap to read it all), over a soft blur of the banner. The header scrolls away; the tabs stay (#10).
- **Both channels on a collab.** A video made by two channels shows both channel pictures, like YouTube.
- **Hide the tab names.** Settings › Customization › Tab names: off leaves only the icons in the bottom bar.

### 🛠️ Changed

- Channel pictures on cards load sooner while you scroll and fade in instead of popping in.
- The search filters YouTube no longer has (Last hour, sort by upload date or rating) are gone.

## 3.0.0

> **Your own bottom bar, three app icons, a truthful quality label**<br>
> 📅 2026-10-19

### ✨ New

- **Choose your bottom bar.** Home, Search and You always stay; the tab before Search and the tab after it are yours: Shorts, Subscriptions, Downloads, History or none. Settings › Customization › Tabs. Picking what the other tab shows swaps the two. Subscriptions can be on the bar again (#7).
- **A third icon: MeeTube (Fantasy).** The red heart with a white play button on a white tile, beside MeeTube (default) and MeeTube (Classic). The icon list shows each one.
- **The icon is everywhere.** The icon you pick now also shows in the Home pill, the launch screen and the update sheet, not only on the home screen. Picking one offers Restart to switch right away.

### 🛠️ Changed

- Settings choices (theme, app icon, interface size, ...) open in a bottom sheet instead of a pop-up in the middle of the screen.
- Switches and the picked option are red, the app's accent colour.
- Trending is gone from Tabs and You: YouTube removed it and its feed came back empty.

### 🐛 Fixed

- **"Auto (1080p60)" on videos without 60 fps.** In Auto the Quality row showed the Auto ceiling instead of the quality playing. It now shows the real one, for example "Auto (720p)" in the small player and "Auto (1080p)" in fullscreen (#8).
- **Subscriptions never reached the bottom bar** when turned on in Settings › Tabs (#7).
- Long tab names such as Subscriptions fit their tab instead of ending in "...".

## 2.9.9

> **Shorts in picture-in-picture, channel pictures, a new icon**<br>
> 📅 2026-10-18

### ✨ New

- **Shorts in picture-in-picture.** Press Home while a short plays and it keeps playing in a portrait window with previous, play/pause and next, like YouTube.
- **Channel pictures on cards.** Home, Subscriptions and Search show each channel's picture beside the video title. Tap the picture or the channel name to open the channel.
- **Sort a channel.** The new button on a channel page sorts its videos by Latest, Popular or Oldest.
- **Choose your double-tap.** Settings › Playback › Double-tap to seek: 3, 5, 10, 15 or 30 seconds.
- **A new icon.** A glossy heart with a play button, on the home screen, the launch animation and the Home pill. Prefer the old one? Settings › Customization › App icon › Classic.
- **Customization page.** Settings › Customization holds the theme, app icon, glass, interface size, start screen, Home layout, tabs, video menu, thumbnails and playlist style. General keeps language, country, voice search and number formats.
- **Update pop-up.** When a new version is out, MeeTube asks once with Update now or Later. Later asks again a day later; Don't ask again turns it off (Settings › About › Update pop-up).

### 🛠️ Changed

- Group titles in Settings and pop-ups are smaller and red, so they no longer look like options.
- The account and Buy me a coffee rows left the top of Settings. Switch accounts from the You tab; the thank-you stays at the bottom of About.
- Updating to 2.9.9 removes MeeTube from your home screen once (the launcher entry was renamed for the icon choice). It is still in the app drawer; pin it again from there.

### 🐛 Fixed

- **Ads in the Shorts feed.** Promoted shorts are now dropped.
- **Shorts wouldn't swipe right after opening.** The Shorts tab could open on a single subscription short before the rest of the feed arrived, and a swipe did nothing. It now waits for the next short.
- **Shorts picture-in-picture turned landscape on next.** The window keeps the short's shape while the next one loads.
- **Home could crash** reattaching the mini player's video.
- Searches that failed once are retried properly, and captions are no longer offered from auto-dubbed audio (from SmartTube).

## 2.9.8

> **Home filters, sleep timer, steadier background play**<br>
> 📅 2026-10-17

### ✨ New

- **Filters on Home.** Liquid-glass chips at the top of Home: All, Music, Gaming, News, Sports and Live. They slide away as you scroll down; scrolling back up shows a small arrow beside the MeeTube pill that brings them back.
- **Home as rows.** Settings › General › Home layout › Rows shows Home like SmartTube: one titled row per topic that you swipe sideways. Feed stays the default.
- **Channels on Subscriptions.** A row of your subscribed channels heads Subscriptions. Tap one to see only that channel's videos; tap All for everything again.
- **Sleep timer.** In the player's settings: pause after 10 to 90 minutes, or at the end of the video.
- **Autoplay switch.** In the player's settings, one tap turns playing the next video on or off.
- **Video quality for Wi-Fi and mobile data.** Settings › Video quality has a default for each. Mobile data starts as "Same as Wi-Fi".

### 🐛 Fixed

- **Music stopped, and the app was closed, with the screen off.** MeeTube now keeps the phone awake and connected while it plays, and asks once to be allowed to run in the background, which battery savers on phones like realme respect. Settings › Playback › "Keep playing with the screen off" shows whether it's allowed.

## 2.9.6

> **Hotfix**<br>
> 📅 2026-10-15

### 🐛 Fixed

- **The player could freeze half-shrunk.** A back swipe in the vertical fullscreen left the video stuck part-way to the mini player, with the page dimmed and no button or gesture working. Back now just leaves the vertical fullscreen, and if the player is ever caught half-way, Back puts it right.

## 2.9.5

> **Headphones on the mini player, iOS-style switches**<br>
> 📅 2026-10-15

### ✨ New

- **Headphones on the mini player.** The in-app mini player has a headphones button to switch to audio only, and so does its floating picture-in-picture window.
- **iOS-style switches.** Settings switches are compact capsules with a white pill knob that turns into clear glass as it slides.
- **Frosted search in Settings.** The "Search settings" bar is liquid glass, and the list scrolls under it. It follows the Liquid glass setting.
- **Buy me a coffee.** If you love MeeTube and want to support it, there's a link in Settings and a small thank-you at the bottom of About.

### 🛠️ Changed

- **Pulling down into the vertical fullscreen follows your finger,** and springs back if you let go early. Going in and coming back out are smoother.
- **Smoother picture-in-picture from the mini player.** Its buttons hide before the window shrinks, and the card eases back into its corner when you return.
- **In the vertical fullscreen, the minimize and headphones buttons sit under the seek bar,** within reach of your thumb, and the top buttons stay clear of the camera notch.

## 2.9.3

> **Lyrics providers, smoother comments and fullscreen**<br>
> 📅 2026-10-15

### ✨ New

- **Choose your lyrics provider.** Like BitChord, the lyrics panel lists every source that has the song's words, and you can switch between them.
- **Glass buttons on Shorts.** Like, comments, share and the other buttons sit on the same frosted liquid glass as the player's buttons.
- **Remove from playlist and Watch later, from the card menu,** on your own playlists (from NewTube).
- **Channel links open,** including @handle links, and the channel page shows its name (from NewTube).

### 🛠️ Changed

- **Pulling Home to refresh shows videos you haven't seen.** The videos already on screen make room for the rest of YouTube's picks, with no extra wait.
- **Writing a comment shows a single bar,** with your picture and a rounded glass pill, and it rises smoothly with the keyboard.
- **The vertical fullscreen opens and closes smoothly,** without the page vanishing or the video jumping.
- **The Liquid glass setting covers every glass surface,** the player's and Shorts' buttons included.

### 🐛 Fixed

- **The lyrics panel fades away with the player** when you swipe the video down to the mini player, like comments and the description.
- **No more stray Shorts tiles in a channel's navigation row,** and the untitled row of channel tabs is called "More" (from NewTube).
- **The screen can sleep when the mini player is paused under a menu,** and a dubbed video's download keeps the right audio if the app closes mid-download (from NewTube).

## 2.9.2

> **Lyrics, liquid glass player, Description panel**<br>
> 📅 2026-10-14

### ✨ New

- **Lyrics for every song.** The Music button is now Lyrics: a panel under the video with the song's words, found across BitChord's lyrics sources (lrc.red, LyricsPlus, KuGou, LRCLIB, YouTube Music, Genius and more). Timed lyrics light up line by line with the song; tapping the video still works the player.
- **Liquid glass player buttons.** Every button over the video sits on frosted glass that blurs the picture behind it, in portrait, landscape and the vertical fullscreen.
- **A YouTube-style Description panel.** Tapping the title opens the description in a frosted panel under the video, with likes, views and the date, and text you can copy. The video keeps playing, undimmed.
- **Swipe between a channel's tabs.** Slide left or right on a channel's videos to change tabs.
- **Frosted comments.** The comments panel, the "Add a comment" pill and the sort and comment menus are frosted glass.

### 🛠️ Changed

- **Swipe up to leave the vertical fullscreen,** as well as down, and it settles smoothly.

### 🐛 Fixed

- **Comments by people with Arabic or Hebrew names read properly.** The name line no longer jumbles the date ("days ago 4 •"), and replies that are just a timestamp line up with the rest.

## 2.8.0

> **Search tab and filters, Shorts edge to edge, floating mini player**<br>
> 📅 2026-10-13

### ✨ New

- **Search has its own tab.** Search now sits in the bottom bar where Subscriptions was (Subscriptions is in the You panel), and the search icon left the top bar.
- **Search filters are back.** The button next to the search bar narrows results by upload date (last hour to this year), length, type (videos, channels, playlists, movies) and features (live, 4K, HDR), and sorts them by date, views or rating.
- **The mini player floats when you leave the app.** Going home while the mini player plays on Home now opens a picture-in-picture window. Expanding it brings you back; closing it stops the video.
- **Shorts fill the screen, edge to edge.** Ambient blur takes the strips under the status and navigation bars, and the video's edges fade into it.
- **A frosted glass search bar that glows as you type.** Results scroll under a frosted search bar with clear and voice search inside it. What you type glows in Siri's colours, and opening Search lights up the screen's edges.
- **A beating heart on launch.** The heart beats once on the start screen (Android 12 and later) and in the top bar.

### 🛠️ Changed

- **Shorts pause when you leave the app.** Shorts no longer open picture-in-picture, play in the background or shrink to the mini player; coming back plays them again.

### 🐛 Fixed

- **Shorts no longer turn into normal videos at random.** A Short could lose track of the Shorts feed and open on the watch page, and the end of the loaded Shorts fell back to an ordinary next video.
- **Picture-in-picture fills its window for vertical and square videos.** It showed the video in the top half over black, with the fullscreen button below.
- **The screen sleeps when a video ends or is paused.** It used to stay on until the battery ran out.
- **An audio track you pick applies to that video only.** A dub chosen once no longer follows you to every dubbed video, and "en" no longer matches "ben".
- **Downloads of dubbed videos keep the original audio,** also after a retry.
- **Original titles work, with or without DeArrow.**
- **Backups leave your sign-in tokens out.** Android's backup and the app's backup file restore signed out.
- **Fullscreen works on tablets,** where Android 16 ignores rotation requests.
- **No blank Shorts tile on channel pages, and no channel actions on playlist cards.**

The last seven fixes come from NewTube 1.15.1.

## 2.5.7

> **Music button opens your music app**<br>
> 📅 2026-10-09

### 🐛 Fixed

- **Music button opens whichever app you chose for YouTube Music links.** It used to open only the YouTube Music app. Now it follows Android's "Open by default" setting, so apps like BitChord work, and without a music app it opens in the browser.

## 2.5.6

> **Picture-in-picture every time, and a Music button**<br>
> 📅 2026-10-09

### ✨ New

- **Picture-in-picture whenever you leave a playing video.** Going home or switching apps now always shrinks the video into a floating window. The old "Play in background" setting is gone; the headphones button is how you ask for audio only.
- **Headphones in the picture-in-picture window.** Tap the window, then the headphones: the window closes and the sound keeps playing.
- **Music button.** For songs and music videos, a Music button next to Share opens the video in YouTube Music. It only shows for videos that YouTube Music has.

### 🐛 Fixed

- **Smoother picture-in-picture.** MeeTube no longer resends the window's buttons every time the video buffers, which stalled the window's animation.

## 2.5.1

> **Audio only, new icon and fixes**<br>
> 📅 2026-10-09

### ✨ New

- **Audio only.** Tap the headphones at the top left of the player to listen without the video: no video is downloaded, the thumbnail stays on screen, and pressing Home keeps the sound playing instead of opening a picture-in-picture window. Tap again for the video.
- **A new icon.** A red heart with a play button, on black, on the launcher and in the top bar.

### 🐛 Fixed

- **No more crash after picture-in-picture at high quality.** At 1440p and above, MeeTube kept up to two minutes of already-watched video in memory, and coming back from picture-in-picture could run out of memory. Video memory now has a hard limit tied to what the app may use; seeking back more than 20 seconds reloads from the disk cache.
- **Settings in fullscreen.** The settings and More menus no longer bring back the status and navigation bars, and no longer show a second plain panel beside the frosted one.
- **Diagnostic logs are named meetube-diagnostics.**

## 2.5.0

> **Glass and quicker Shorts**<br>
> 📅 2026-10-09

### ✨ New

- **Up next countdown.** When a video ends, a small card in the player counts down ten seconds to the next one. Tap Play now to go at once, Replay to watch it again, or Cancel to stay put. Seeking back cancels it too.
- **A splash when you like or subscribe.** A ring and a burst of colour come off the button.
- **Floating glass top bar.** The full-width bar is gone: the MeeTube logo and the cast and search buttons float as two liquid glass pills, like the navigation bar.
- **A quote when you tap the MeeTube logo.** It shows for three seconds, and every tap brings a new one: no quote comes back until you have seen them all.
- **Frosted menus.** The player's settings, More and card menus are frosted glass over a blurred copy of what's behind them, while the page around them stays sharp.
- **Liquid glass setting.** Turn it off in Settings → General for a plain frosted blur that is easier on the battery.
- **Counts in K and M.** Views and likes read 250K and 12M even when your phone is set to English (India). Prefer lakh and crore? Turn on Lakh and crore counts in Settings → General.

### 🛠️ Changed

- **Shorts swipe faster.** MeeTube now looks up the short after the next one in advance, and a short that was still preloading when you swiped to it plays from what it already has instead of starting over. Neighbouring thumbnails load at once.
- **Subscribed is a glass pill**, like the buttons above it.
- **The title and view count of a video are one button** that opens the description.
- **A small bounce on the navigation bar** when you switch tabs.
- **Downloads go to Movies/MeeTube and Music/MeeTube.** Earlier downloads stay where they are.

## 2.0.2

> **Vertical fullscreen**<br>
> 📅 2026-10-08

### ✨ New

- **Vertical fullscreen.** Pull the watch page down from its title and the video fills the upright screen, like YouTube's. The whole picture stays in view, the system bars hide, and the seek bar sits higher, within reach of your thumb. Swipe down on the video or press Back to leave it, or turn the phone sideways for landscape.
- **Ambient colours in vertical fullscreen.** The black bands above and below the video glow with its colours. Ambient mode is on by default; turn it off in Settings → Player → Watch page, or from the player's settings sheet.
- **A floating glass fullscreen button** at the bottom right of the watch page.
- **A new loading animation.** The coral cookie from the icon turns as it morphs into a four-leaf clover and back. It replaces the spinner app-wide.

### 🛠️ Changed

- **Shorts start faster.** While you watch a short, MeeTube now preloads the first seconds of the next one: it asks for the next short 0.3 seconds in (it used to wait 5 seconds) and loads it once the current one has 3 seconds buffered. In testing, a short you swipe to after about 3 seconds started in about half a second.
- **A fatter seek bar while you drag it**, with a bigger dot, like YouTube's.
- **The minimize button in fullscreen** is a small round button, easy to spot over any picture.
- **No page titles in the top bar.** Just the MeeTube logo, cast and search.
- **Shorts comments:** dragging them down no longer shows the short as an ordinary video underneath, and the short grows back to full screen as the comments slide away.

## 2.0.1

> **Feel**<br>
> 📅 2026-10-07

### ✨ New

- **Haptics everywhere.** Every button, card, chip, switch, menu row and bottom-sheet option answers your tap with a light click, and each double-tap seek forward or back clicks too. It follows your phone's touch-vibration setting.
- **True black for AMOLED.** In dark mode the pages, top bar and navigation area are pure black, so an AMOLED screen switches those pixels off and saves battery.
- **Shorts swipe like YouTube.** The next (or previous) short's picture slides in under your finger as you swipe, and stays on screen until the video starts, with no black flash. When nothing is queued yet, the swipe just springs back.
- **Scrub Shorts.** Drag the line at the bottom to jump around a short. A big time readout shows where you are, and the text gets out of the way while you drag.
- **More on Shorts.** A Shorts header with a back arrow; a "more" button for quality, captions and speed; and YouTube's spinning disc with the channel picture. Tap a title to read all of it.

### 🛠️ Changed

- **Shorts you've seen stay seen.** MeeTube remembers the last 3,000 shorts for 7 days, across restarts, so the Shorts tab keeps serving new ones. If a feed has nothing new for three pages, it plays what it has instead of loading forever.
- **The Shorts progress line moves now.** In 2.0.0 it stayed empty while a short played.

## 2.0.0

> **Liquid Glass**<br>
> 📅 2026-10-07

### ✨ New

- **Shorts like YouTube.** The Shorts tab opens straight into the full-screen player, with no grid. The channel, a Subscribe button, the title and views sit at the bottom; like, dislike, comments and share on the right, with their counts; a thin progress line runs along the bottom. Tap to pause, double-tap to like, hold for 2x. Back returns to the tab you came from.
- **Endless, fresh Shorts.** The next page of Shorts loads before you reach the end, a short you have already seen this session is never served again, and the next one is buffered as soon as the current one starts.
- **Comments on Shorts.** The comments open under the short, which shrinks to the top of the screen, like YouTube.
- **Liquid glass.** The floating bar now bends what is under it like a lens, with a soft rainbow edge and a bright rim, and a lighter frost so you can see the page through it. The top bar is frosted glass too: the feed scrolls up under it.
- **A new icon.** A minimal coral "cookie" with a white M, in the Material 3 expressive style, with a themed version for Android 13+.

### 🛠️ Changed

- **Sharper Shorts thumbnails** (YouTube's tall 720×1280 images).
- **A bigger mini player** (216×122dp), landing exactly where the minimize animation ends.
- **Modern switches** in Settings: a rounded capsule, red when on.
- Like counts YouTube does not share no longer show "N/A".

## 1.5.0

> **Shorts**<br>
> 📅 2026-10-07

### ✨ New

- **Shorts.** A Shorts tab with a grid of tall cards. Tap one and it plays full screen; swipe up for the next short and down for the previous one. Each short loops until you swipe, and the next one loads while you watch. Like, dislike and share sit on the right.
- **Ambient glow.** On the watch page the colours of the playing video spread softly under the player and fade into the page, and follow the scene as it changes.
- **A new MeeTube icon.** A rounded M on a coral-to-magenta tile, with a little glass bubble.

### 🛠️ Changed

- **Tap the title to read more.** The arrow is gone: tap a video's title or its views line to open the description, and the title shows in full.
- **Rounded everywhere.** Menus, sheets, dialogs, snackbars and chips have rounded corners, and the Comments panel slides up with a rounded top.
- **History moved to You.** The bottom bar is now Home, Shorts, Subscriptions, Downloads and You.

## 1.0.0

> **Floating Glass**<br>
> 📅 2026-10-07

### ✨ New

- **Floating glass.** The bottom navigation is now a frosted glass capsule floating over the page, with a live blur of what scrolls underneath. On Android 13 and later its edge bends the content like a lens.
- **A new look.** A darker page, a red accent, large tab titles, rounded thumbnails, and glass buttons and cards on the watch page.
- **MeeTube.** A new name and app id, so it installs alongside NewTube. Updates come from github.com/yashoncode/meetube.

### 🛠️ Changed

- **Dark by default.** Light theme is still in Settings → User interface → Theme.
